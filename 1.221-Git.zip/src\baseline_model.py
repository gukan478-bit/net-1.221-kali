"""
baseline_model.py
==================
A simple, non-temporal Logistic Regression baseline trained on the SAME
per-window feature vectors as the LSTM (flattened across the sequence,
i.e. it sees exactly the same information but with no notion of order).
This isolates how much of the LSTM's performance is attributable to
learning temporal structure vs. just having more features/params.

Two things it explicitly does NOT get that the LSTM does:
  - no memory of state ordering (a shuffled sequence looks identical to it)
  - no autoregressive multi-step rollout — it only predicts the immediate
    next-window binary label from the flattened current sequence.
"""

from __future__ import annotations
import logging
from typing import Dict, Any

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler as SkScaler

logger = logging.getLogger("baseline_model")


class SingleClassDataError(Exception):
    """Raised when the training split contains only one label class (e.g.
    an unlabeled/all-benign live capture), which Logistic Regression
    cannot fit a decision boundary on. Callers should treat this as an
    expected condition for unlabeled input, not a crash."""


class BaselineLogisticModel:
    def __init__(self, max_iter: int = 500):
        self.clf = LogisticRegression(max_iter=max_iter, class_weight="balanced")
        self.scaler = SkScaler()
        self._fitted = False
        self._single_class_value: float = None  # set if training data had only one class

    @staticmethod
    def _flatten(X_seq: np.ndarray) -> np.ndarray:
        """(N, seq_len, feat_dim) -> (N, seq_len*feat_dim)."""
        n = X_seq.shape[0]
        return X_seq.reshape(n, -1)

    def fit(self, X_seq: np.ndarray, y_binary_next: np.ndarray) -> "BaselineLogisticModel":
        unique_classes = np.unique(y_binary_next)
        if len(unique_classes) < 2:
            # This happens legitimately for unlabeled/live captures (all
            # windows default to BENIGN) or heavily imbalanced small
            # samples. Logistic Regression cannot fit a boundary with a
            # single class, so we record a constant predictor instead of
            # crashing training — evaluate.py surfaces this explicitly
            # rather than silently reporting fabricated metrics.
            logger.warning(
                "Baseline training data contains only one class (%s). "
                "Falling back to a constant predictor; comparison metrics "
                "against the LSTM will reflect this limitation.",
                unique_classes[0],
            )
            self._single_class_value = float(unique_classes[0])
            self._fitted = True
            return self

        X_flat = self._flatten(X_seq)
        X_scaled = self.scaler.fit_transform(X_flat)
        self.clf.fit(X_scaled, y_binary_next)
        self._fitted = True
        return self

    def predict_proba(self, X_seq: np.ndarray) -> np.ndarray:
        if not self._fitted:
            raise RuntimeError("Baseline model must be fit before predict_proba().")
        if self._single_class_value is not None:
            n = X_seq.shape[0]
            return np.full(n, self._single_class_value, dtype=np.float64)
        X_flat = self._flatten(X_seq)
        X_scaled = self.scaler.transform(X_flat)
        return self.clf.predict_proba(X_scaled)[:, 1]

    def predict(self, X_seq: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        return (self.predict_proba(X_seq) >= threshold).astype(int)
