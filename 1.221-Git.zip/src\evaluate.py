"""
evaluate.py
===========
Computes real metrics (never invented) comparing the LSTM world model
against the Logistic Regression baseline, plus dedicated forecasting and
stage-prediction metrics.

Usage:
    python3 evaluate.py --run-name default

Reads the artifacts saved by train.py: model checkpoint, scaler, baseline
model, and the held-out chronological test sequences.
"""

from __future__ import annotations
import argparse
import json
import logging
import os
import pickle
import sys

import numpy as np
import torch
from sklearn.metrics import (
    precision_score, recall_score, f1_score, roc_auc_score,
    average_precision_score, confusion_matrix, accuracy_score, classification_report,
)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import PATHS, ModelConfig, SequenceConfig, ATTACK_STAGES
from world_model import NetworkWorldModel
from preprocessing import load_json

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("evaluate")


def false_positive_rate(y_true, y_pred) -> float:
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return float(fp) / (fp + tn) if (fp + tn) > 0 else 0.0


def binary_metrics(y_true: np.ndarray, y_prob: np.ndarray, threshold: float = 0.5) -> dict:
    y_pred = (y_prob >= threshold).astype(int)
    metrics = {
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "false_positive_rate": false_positive_rate(y_true, y_pred),
        "accuracy": accuracy_score(y_true, y_pred),
    }
    # ROC-AUC/PR-AUC require both classes present
    if len(np.unique(y_true)) > 1:
        metrics["roc_auc"] = roc_auc_score(y_true, y_prob)
        metrics["pr_auc"] = average_precision_score(y_true, y_prob)
    else:
        metrics["roc_auc"] = None
        metrics["pr_auc"] = None
        logger.warning("Only one class present in y_true — ROC-AUC/PR-AUC undefined for this split.")
    return metrics


def evaluate_forecast_horizon(model: NetworkWorldModel, X: torch.Tensor, Y_binary: torch.Tensor) -> dict:
    """Per-forecast-step (t+1..t+K) metrics — shows whether accuracy degrades
    with forecast distance, which is the honest way to report forecasting
    performance rather than a single blended number."""
    model.eval()
    with torch.no_grad():
        out = model(X)
        probs = torch.sigmoid(out["threat_logits"]).numpy()  # (N, K)
    Yb = Y_binary.numpy()
    K = probs.shape[1]
    per_step = {}
    for k in range(K):
        yt, yp = Yb[:, k], probs[:, k]
        if len(np.unique(yt)) > 1:
            auc = roc_auc_score(yt, yp)
        else:
            auc = None
        pred = (yp >= 0.5).astype(int)
        per_step[f"+{k+1}_step"] = {
            "roc_auc": auc,
            "f1": f1_score(yt, pred, zero_division=0),
            "precision": precision_score(yt, pred, zero_division=0),
            "recall": recall_score(yt, pred, zero_division=0),
        }
    return per_step


def evaluate_stage_prediction(model: NetworkWorldModel, X: torch.Tensor, Y_stage: torch.Tensor) -> dict:
    model.eval()
    with torch.no_grad():
        out = model(X)
        pred_stage = out["stage_logits"].argmax(dim=1).numpy()
    true_stage = Y_stage.numpy()
    present_classes = sorted(set(true_stage.tolist()) | set(pred_stage.tolist()))
    report = {
        "accuracy": accuracy_score(true_stage, pred_stage),
        "macro_f1": f1_score(true_stage, pred_stage, average="macro", zero_division=0),
        "classes_present_in_test": [ATTACK_STAGES[i] for i in present_classes],
    }
    return report


def main():
    parser = argparse.ArgumentParser(description="Evaluate the trained world model vs. baseline.")
    parser.add_argument("--run-name", default="default")
    args = parser.parse_args()

    run_dir = os.path.join(PATHS["models"], args.run_name)
    cfg_path = os.path.join(run_dir, "run_config.json")
    if not os.path.exists(cfg_path):
        logger.error("No run_config.json found at %s — did you run train.py --run-name %s first?",
                      run_dir, args.run_name)
        sys.exit(1)

    run_cfg = load_json(cfg_path)
    seq_cfg = SequenceConfig(sequence_length=run_cfg["sequence_length"],
                              forecast_horizon=run_cfg["forecast_horizon"])
    model_cfg = ModelConfig()

    model = NetworkWorldModel(feature_dim=run_cfg["feature_dim"], model_cfg=model_cfg, seq_cfg=seq_cfg)
    model.load_state_dict(torch.load(os.path.join(run_dir, "world_model.pt"), map_location="cpu"))
    model.eval()

    with open(os.path.join(run_dir, "baseline_model.pkl"), "rb") as f:
        baseline = pickle.load(f)

    test_npz = np.load(os.path.join(run_dir, "test_sequences.npz"))
    X_test, Y_binary_test, Y_stage_test = test_npz["X"], test_npz["Y_binary"], test_npz["Y_stage"]

    if X_test.shape[0] == 0:
        logger.error("Test split has zero sequences — cannot evaluate. "
                      "Provide more data or reduce sequence_length/forecast_horizon.")
        sys.exit(1)

    Xt = torch.tensor(X_test, dtype=torch.float32)
    Ybt = torch.tensor(Y_binary_test, dtype=torch.float32)
    Ygt = torch.tensor(Y_stage_test, dtype=torch.long)

    logger.info("Evaluating on %d held-out (chronologically-final) test sequences.", X_test.shape[0])

    # --- LSTM: immediate-next-step binary metrics ---
    with torch.no_grad():
        lstm_probs_step0 = torch.sigmoid(model(Xt)["threat_logits"][:, 0]).numpy()
    lstm_immediate = binary_metrics(Y_binary_test[:, 0], lstm_probs_step0)

    # --- Baseline: immediate-next-step binary metrics ---
    baseline_probs = baseline.predict_proba(X_test)
    baseline_immediate = binary_metrics(Y_binary_test[:, 0], baseline_probs)

    # --- Forecasting performance across the full horizon ---
    forecast_report = evaluate_forecast_horizon(model, Xt, Ybt)

    # --- Stage prediction performance ---
    stage_report = evaluate_stage_prediction(model, Xt, Ygt)

    attack_family_report = None
    if "attack_features" in test_npz and "attack_categories" in test_npz:
        classifier_path = os.path.join(run_dir, "attack_classifier.pkl")
        if os.path.exists(classifier_path):
            with open(classifier_path, "rb") as f:
                attack_classifier = pickle.load(f)
            attack_true = test_npz["attack_categories"].astype(str)
            attack_pred = attack_classifier.predict(test_npz["attack_features"])
            attack_family_report = {
                "accuracy": accuracy_score(attack_true, attack_pred),
                "macro_f1": f1_score(
                    attack_true, attack_pred, average="macro", zero_division=0
                ),
                "classes_present_in_test": sorted(set(attack_true.tolist())),
                "classification_report": classification_report(
                    attack_true, attack_pred, output_dict=True, zero_division=0
                ),
            }

    results = {
        "run_name": args.run_name,
        "test_set_size": int(X_test.shape[0]),
        "comparison_immediate_next_window": {
            "lstm_world_model": lstm_immediate,
            "logistic_regression_baseline": baseline_immediate,
        },
        "forecast_performance_by_horizon": forecast_report,
        "stage_prediction_performance": stage_report,
        "attack_family_performance": attack_family_report,
    }

    report_path = os.path.join(PATHS["reports"], f"{args.run_name}_evaluation.json")
    with open(report_path, "w") as f:
        json.dump(results, f, indent=2, default=lambda o: None)

    # --- Plain-text summary ---
    print("\n" + "=" * 60)
    print(f" EVALUATION REPORT — run: {args.run_name}")
    print("=" * 60)
    print(f"Test sequences: {X_test.shape[0]}\n")

    print("Immediate next-window detection (LSTM vs. baseline):")
    print(f"{'Metric':<20}{'LSTM':>12}{'LogReg':>12}")
    for k in ["precision", "recall", "f1", "false_positive_rate", "roc_auc", "pr_auc"]:
        lv = lstm_immediate.get(k)
        bv = baseline_immediate.get(k)
        lv_s = f"{lv:.3f}" if lv is not None else "n/a"
        bv_s = f"{bv:.3f}" if bv is not None else "n/a"
        print(f"{k:<20}{lv_s:>12}{bv_s:>12}")

    print("\nForecast performance by horizon step (LSTM):")
    for step, m in forecast_report.items():
        auc_s = f"{m['roc_auc']:.3f}" if m["roc_auc"] is not None else "n/a"
        print(f"  {step:<10} f1={m['f1']:.3f}  precision={m['precision']:.3f}  "
              f"recall={m['recall']:.3f}  roc_auc={auc_s}")

    print("\nAttack-stage prediction (at forecast horizon K):")
    print(f"  accuracy = {stage_report['accuracy']:.3f}")
    print(f"  macro_f1 = {stage_report['macro_f1']:.3f}")
    print(f"  classes present in test set: {stage_report['classes_present_in_test']}")
    if attack_family_report is not None:
        print("\nAttack-family classification (held-out final 15%):")
        print(f"  accuracy = {attack_family_report['accuracy']:.3f}")
        print(f"  macro_f1 = {attack_family_report['macro_f1']:.3f}")
        print(f"  classes present in test set: {attack_family_report['classes_present_in_test']}")

    print(f"\nFull JSON report written to: {report_path}")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
