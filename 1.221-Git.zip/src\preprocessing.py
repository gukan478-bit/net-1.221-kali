"""
preprocessing.py
=================
Bridges windowing.py's raw state matrices and the world model:
  1. chronological train/val/test split (no shuffling — order is time)
  2. scaler fit ONLY on the training split, applied to all splits
  3. sequence-of-states construction: (X_seq, y_prob, y_stage) tuples
     where X_seq is `sequence_length` consecutive states and the targets
     look `forecast_horizon` steps into the future.
  4. dataset-label -> MITRE stage heuristic mapping (probabilistic, never
     asserted as ground truth beyond what the dataset's own label says).

Leakage safeguards implemented here:
  - split index is computed on the TIME axis before anything else touches
    the data; scaler.fit() is only ever called on data strictly before the
    split point.
  - sequence windows never cross the split boundary (a sequence that would
    need states from both sides of the boundary is dropped).
"""

from __future__ import annotations
import json
import os
import pickle
from typing import Tuple, List, Dict, Any, Optional

import numpy as np

from config import (
    FEATURE_VECTOR_ORDER, STAGE_TO_INDEX, SequenceConfig, DEFAULT_SEQUENCE,
    PATHS, RANDOM_SEED,
)

np.random.seed(RANDOM_SEED)


# --------------------------------------------------------------------------
# Scaling (self-contained standard scaler — avoids a hard sklearn dependency
# for this one step, though sklearn is used elsewhere for the baseline model
# and metrics; keeping this local makes it trivial to pickle alongside the
# LSTM checkpoint without version-coupling to sklearn's Scaler internals)
# --------------------------------------------------------------------------
class StandardScaler:
    def __init__(self):
        self.mean_: Optional[np.ndarray] = None
        self.std_: Optional[np.ndarray] = None

    def fit(self, X: np.ndarray) -> "StandardScaler":
        self.mean_ = X.mean(axis=0)
        std = X.std(axis=0)
        std[std < 1e-8] = 1.0  # avoid divide-by-zero on constant columns
        self.std_ = std
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        if self.mean_ is None:
            raise RuntimeError("Scaler must be fit before transform().")
        return (X - self.mean_) / self.std_

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        return self.fit(X).transform(X)

    def save(self, path: str):
        with open(path, "wb") as f:
            pickle.dump({"mean": self.mean_, "std": self.std_}, f)

    @classmethod
    def load(cls, path: str) -> "StandardScaler":
        obj = cls()
        with open(path, "rb") as f:
            d = pickle.load(f)
        obj.mean_, obj.std_ = d["mean"], d["std"]
        return obj


# --------------------------------------------------------------------------
# Chronological split
# --------------------------------------------------------------------------
def chronological_split(n: int, train_frac: float = 0.7, val_frac: float = 0.15
                         ) -> Tuple[Tuple[int, int], Tuple[int, int], Tuple[int, int]]:
    """
    Returns (train_range, val_range, test_range) as (start, end) index
    pairs over a TIME-ORDERED array of length n. No shuffling — this is
    the core defense against temporal leakage.
    """
    train_end = int(n * train_frac)
    val_end = int(n * (train_frac + val_frac))
    return (0, train_end), (train_end, val_end), (val_end, n)


# --------------------------------------------------------------------------
# Label -> MITRE stage mapping
# --------------------------------------------------------------------------
# This maps the RAW label strings found in public IDS datasets to our
# internal stage taxonomy. This is an explicit, editable, human-readable
# table — not a learned or hidden mapping — precisely so that the
# probabilistic-inference caveat in config.py's ATTACK_STAGES stays
# auditable. Extend this table when adding a new dataset adapter.
LABEL_TO_STAGE: Dict[str, str] = {
    "benign": "BENIGN",
    "normal": "BENIGN",
    # reconnaissance
    "portscan": "RECONNAISSANCE",
    "port scan": "RECONNAISSANCE",
    "nmap": "RECONNAISSANCE",
    "reconnaissance": "RECONNAISSANCE",
    "probe": "RECONNAISSANCE",
    "scanning": "RECONNAISSANCE",
    # credential access
    "ftp-patator": "CREDENTIAL_ACCESS",
    "ssh-patator": "CREDENTIAL_ACCESS",
    "brute force": "CREDENTIAL_ACCESS",
    "bruteforce": "CREDENTIAL_ACCESS",
    "web attack - brute force": "CREDENTIAL_ACCESS",
    "ftp-bruteforce": "CREDENTIAL_ACCESS",
    "ssh-bruteforce": "CREDENTIAL_ACCESS",
    # impact / DoS-DDoS
    "dos": "IMPACT",
    "ddos": "IMPACT",
    "dos hulk": "IMPACT",
    "dos goldeneye": "IMPACT",
    "dos slowloris": "IMPACT",
    "dos slowhttptest": "IMPACT",
    "syn flood": "IMPACT",
    "udp flood": "IMPACT",
    "icmp flood": "IMPACT",
    "http flood": "IMPACT",
    "heartbleed": "IMPACT",
    # initial access / exploitation
    "web attack - sql injection": "INITIAL_ACCESS",
    "sql injection": "INITIAL_ACCESS",
    "web attack - xss": "INITIAL_ACCESS",
    "xss": "INITIAL_ACCESS",
    "infiltration": "INITIAL_ACCESS",
    "exploits": "INITIAL_ACCESS",
    "backdoor": "PERSISTENCE",
    # lateral movement / discovery
    "lateral movement": "LATERAL_MOVEMENT",
    "discovery": "DISCOVERY",
    # botnet / c2
    "bot": "COMMAND_AND_CONTROL",
    "botnet": "COMMAND_AND_CONTROL",
    "c2": "COMMAND_AND_CONTROL",
    "command and control": "COMMAND_AND_CONTROL",
    # exfiltration
    "exfiltration": "EXFILTRATION",
    "data exfiltration": "EXFILTRATION",
    # generic / dataset-specific catch-alls resolved per-adapter
    "generic": "IMPACT",
    "fuzzers": "DISCOVERY",
    "analysis": "DISCOVERY",
    "shellcode": "EXECUTION",
    "worms": "LATERAL_MOVEMENT",
    # UNSW-NB15 attack_cat values
    "analysis": "DISCOVERY",
    "backdoor": "PERSISTENCE",
    "exploits": "INITIAL_ACCESS",
    "fuzzers": "DISCOVERY",
    "generic": "IMPACT",
    "reconnaissance": "RECONNAISSANCE",
    "shellcode": "EXECUTION",
    "worms": "LATERAL_MOVEMENT",
}


def normalize_attack_category(raw_label: str) -> str:
    """Normalize common dataset spellings into stable dashboard classes."""
    key = " ".join(str(raw_label).strip().lower().replace("_", " ").replace("-", " ").split())
    if key in {"", "0", "normal", "benign"}:
        return "Normal"
    if key in {"ddos", "dos", "dos hulk", "dos goldeneye", "dos slowloris",
               "dos slowhttptest", "syn flood", "udp flood", "icmp flood",
               "http flood"} or "ddos" in key:
        return "DDoS/DoS"
    if (key in {"brute force", "bruteforce", "ftp patator", "ssh patator",
                "ftp brute force", "ssh brute force"} or "patator" in key
            or "brute" in key or "bruteforce" in key):
        return "Brute Force"
    return str(raw_label).strip() or "Unknown"


def label_to_stage_index(raw_label: str) -> int:
    """
    Map a raw dataset label to a stage index. Unknown labels fall back to
    BENIGN=0 is WRONG (would hide real attacks); instead unknown non-benign
    labels map to IMPACT-adjacent 'DISCOVERY' bucket only as a last resort
    AND are logged so the adapter's label coverage can be audited/extended
    — never silently dropped.
    """
    key = raw_label.strip().lower()
    normalized = normalize_attack_category(raw_label).lower()
    if normalized == "normal":
        return STAGE_TO_INDEX["BENIGN"]
    if normalized == "ddos/dos":
        return STAGE_TO_INDEX["IMPACT"]
    if normalized == "brute force":
        return STAGE_TO_INDEX["CREDENTIAL_ACCESS"]
    if key in LABEL_TO_STAGE:
        return STAGE_TO_INDEX[LABEL_TO_STAGE[key]]
    if key in ("", "0"):
        return STAGE_TO_INDEX["BENIGN"]
    # heuristic substring matches for label variants not enumerated above
    for substr, stage in LABEL_TO_STAGE.items():
        if substr in key:
            return STAGE_TO_INDEX[stage]
    return -1  # explicit "unmapped" sentinel — caller must handle/report


# --------------------------------------------------------------------------
# Sequence construction
# --------------------------------------------------------------------------
def build_sequences(state_matrix: np.ndarray,
                     stage_labels: Optional[np.ndarray] = None,
                     binary_labels: Optional[np.ndarray] = None,
                     seq_cfg: SequenceConfig = DEFAULT_SEQUENCE
                     ) -> Dict[str, np.ndarray]:
    """
    Slide a window of `sequence_length` states across state_matrix to build
    training examples. Each example's target is:
      - future_states:  the next `forecast_horizon` state vectors (for the
                         world-model's state-prediction head)
      - future_binary:  binary attack/benign label at each of the K future
                         steps (for the threat-probability-timeline head)
      - future_stage:   attack-stage class at t+K (for stage prediction)

    If labels are None (unlabeled/inference-time input), only X sequences
    are returned — used by forecast.py on live captures.
    """
    n, d = state_matrix.shape
    L = seq_cfg.sequence_length
    K = seq_cfg.forecast_horizon

    X, Y_states, Y_binary, Y_stage = [], [], [], []
    last_start = n - L - K
    for start in range(0, max(0, last_start) + 1):
        x_seq = state_matrix[start:start + L]
        if x_seq.shape[0] != L:
            continue
        X.append(x_seq)

        if stage_labels is not None and binary_labels is not None:
            fut_states = state_matrix[start + L:start + L + K]
            fut_binary = binary_labels[start + L:start + L + K]
            fut_stage = stage_labels[start + L + K - 1]  # stage at final forecast step
            Y_states.append(fut_states)
            Y_binary.append(fut_binary)
            Y_stage.append(fut_stage)

    result = {"X": np.array(X, dtype=np.float32)}
    if Y_states:
        result["Y_states"] = np.array(Y_states, dtype=np.float32)
        result["Y_binary"] = np.array(Y_binary, dtype=np.float32)
        result["Y_stage"] = np.array(Y_stage, dtype=np.int64)
    return result


def save_json(obj: Any, path: str):
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)


def load_json(path: str) -> Any:
    with open(path, "r") as f:
        return json.load(f)
