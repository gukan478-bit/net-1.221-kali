"""
test_windowing.py
==================
Unit tests for windowing.py — verifies windows are chronologically
ordered, feature vectors match FEATURE_VECTOR_ORDER, and no lookahead
leakage occurs across window boundaries.
"""

import os
import sys
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from config import FEATURE_VECTOR_ORDER, WindowConfig
from windowing import build_state_sequence, compute_window_features, _bucket_records


def _make_packet(ts, src_ip="10.0.0.1", dst_ip="10.0.0.2", src_port=1234,
                  dst_port=80, protocol="TCP", tcp_flags="S", ttl=64,
                  tcp_window=8192, ip_frag=0, payload_size=100, packet_length=140,
                  iat=0.01, is_retransmission=0):
    return {
        "timestamp": ts, "src_ip": src_ip, "dst_ip": dst_ip, "src_port": src_port,
        "dst_port": dst_port, "protocol": protocol, "tcp_flags": tcp_flags, "ttl": ttl,
        "tcp_window": tcp_window, "ip_frag": ip_frag, "payload_size": payload_size,
        "packet_length": packet_length, "iat": iat, "is_retransmission": is_retransmission,
    }


def test_bucketing_is_chronological_and_non_overlapping():
    records = [_make_packet(ts) for ts in [0.0, 1.0, 9.9, 10.0, 15.0, 25.5]]
    buckets = _bucket_records(records, window_seconds=10, stride_seconds=10)
    assert set(buckets.keys()) == {0, 1, 2}
    assert len(buckets[0]) == 3   # ts 0.0, 1.0, 9.9
    assert len(buckets[1]) == 2   # ts 10.0, 15.0
    assert len(buckets[2]) == 1   # ts 25.5


def test_window_features_have_correct_keys_and_order():
    records = [_make_packet(ts) for ts in [0.0, 1.0, 2.0]]
    feats = compute_window_features(records, window_seconds=10)
    assert list(feats.keys()) == FEATURE_VECTOR_ORDER
    assert feats["packet_count"] == 3.0


def test_empty_window_returns_zero_vector():
    feats = compute_window_features([], window_seconds=10)
    assert all(v == 0.0 for v in feats.values())


def test_build_state_sequence_shape_and_order():
    records = []
    for i in range(30):
        records.append(_make_packet(ts=float(i)))  # 30 packets over 30s -> 3 windows of 10s
    cfg = WindowConfig(window_seconds=10, stride_seconds=10)
    state_matrix, raw_windows, start_times = build_state_sequence(records, cfg)

    assert state_matrix.shape == (3, len(FEATURE_VECTOR_ORDER))
    assert start_times == [0, 10, 20]
    # chronological: packet_count column should reflect 10 packets each window
    packet_count_idx = FEATURE_VECTOR_ORDER.index("packet_count")
    assert list(state_matrix[:, packet_count_idx]) == [10.0, 10.0, 10.0]


def test_syn_scan_signature_detected():
    """A port scan (one src IP hitting many dst ports) should show high
    unique_dst_ports_per_src and high syn_rate relative to normal traffic."""
    scan_records = [
        _make_packet(ts=float(i), src_ip="10.0.0.5", dst_port=1000 + i, tcp_flags="S")
        for i in range(20)
    ]
    normal_records = [
        _make_packet(ts=float(i), src_ip="10.0.0.5", dst_port=443, tcp_flags="SA")
        for i in range(20)
    ]
    scan_feats = compute_window_features(scan_records, window_seconds=10)
    normal_feats = compute_window_features(normal_records, window_seconds=10)

    assert scan_feats["unique_dst_ports_per_src"] > normal_feats["unique_dst_ports_per_src"]
    assert scan_feats["syn_rate"] >= normal_feats["syn_rate"]


def test_no_lookahead_leakage_between_windows():
    """Features for window 0 must be identical whether or not later
    windows' data exists in the input stream (no future leakage)."""
    early = [_make_packet(ts=float(i)) for i in range(5)]
    late = [_make_packet(ts=float(i), dst_port=9999) for i in range(20, 25)]

    feats_without_future = compute_window_features(early, window_seconds=10)
    feats_with_future_present_elsewhere = compute_window_features(early, window_seconds=10)
    # computing window 0's features never even receives 'late' records,
    # so this equality holds trivially by construction — the real
    # guarantee is enforced by _bucket_records's timestamp-based split,
    # tested above in test_bucketing_is_chronological_and_non_overlapping.
    assert feats_without_future == feats_with_future_present_elsewhere
