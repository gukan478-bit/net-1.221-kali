"""
forecast.py
===========
Live/offline inference entry point. Takes a PCAP or flow CSV, runs it
through the full pipeline, and produces the attack-probability timeline,
predicted future attack stage, contributing features, and suspicious
flows — either as a returned dict (for main.py's dashboard rendering) or
printed directly when run standalone.

Usage:
    python3 forecast.py --pcap captures/capture.pcap --steps 5
    python3 forecast.py --csv traffic.csv --run-name default
"""

from __future__ import annotations
import argparse
import logging
import os
import pickle
import sys
from typing import Dict, Any, List

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import (
    PATHS, ATTACK_STAGES, DEFAULT_ALERT, SequenceConfig, ModelConfig,
    FEATURE_VECTOR_ORDER,
)
from feature_extraction import extract, PacketParseError
from windowing import build_state_sequence, report_feature_availability, WindowConfig
from preprocessing import StandardScaler, build_sequences, load_json
from world_model import NetworkWorldModel
from explain import explain_alert, suspicious_flows

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("forecast")


class ForecasterNotTrainedError(Exception):
    pass


def load_run_artifacts(run_name: str):
    run_dir = os.path.join(PATHS["models"], run_name)
    cfg_path = os.path.join(run_dir, "run_config.json")
    if not os.path.exists(cfg_path):
        raise ForecasterNotTrainedError(
            f"No trained model found for run '{run_name}' at {run_dir}. "
            f"Run train.py first, e.g.: python3 train.py --dataset cic-ids2018 "
            f"--data-dir data/raw/cic-ids2018 --run-name {run_name}"
        )
    run_cfg = load_json(cfg_path)
    seq_cfg = SequenceConfig(sequence_length=run_cfg["sequence_length"],
                              forecast_horizon=run_cfg["forecast_horizon"])
    model_cfg = ModelConfig()
    model = NetworkWorldModel(feature_dim=run_cfg["feature_dim"], model_cfg=model_cfg, seq_cfg=seq_cfg)
    model.load_state_dict(torch.load(os.path.join(run_dir, "world_model.pt"), map_location="cpu"))
    model.eval()

    scaler = StandardScaler.load(os.path.join(PATHS["scalers"], f"{run_name}_scaler.pkl"))
    window_cfg = WindowConfig(window_seconds=run_cfg["window_seconds"],
                               stride_seconds=run_cfg["window_seconds"])
    classifier = None
    classifier_path = os.path.join(run_dir, "attack_classifier.pkl")
    if os.path.exists(classifier_path):
        with open(classifier_path, "rb") as f:
            classifier = pickle.load(f)
    return model, scaler, seq_cfg, window_cfg, run_cfg, classifier


def run_forecast(input_path: str, run_name: str = "default", steps: int = None) -> Dict[str, Any]:
    model, scaler, seq_cfg, window_cfg, run_cfg, attack_classifier = load_run_artifacts(run_name)
    steps = steps or seq_cfg.forecast_horizon

    records = extract(input_path)
    if not records:
        raise PacketParseError(f"No records could be extracted from {input_path}")

    availability = report_feature_availability(records)
    state_matrix, raw_windows, start_times = build_state_sequence(records, window_cfg)

    if state_matrix.shape[0] < seq_cfg.sequence_length:
        raise ValueError(
            f"Input only produced {state_matrix.shape[0]} time windows but the "
            f"model needs at least {seq_cfg.sequence_length} (sequence_length) "
            f"to make a prediction. Capture more traffic or reduce --window size."
        )

    scaled_matrix = scaler.transform(state_matrix)

    # use the MOST RECENT sequence_length windows as "current" context
    x_current = scaled_matrix[-seq_cfg.sequence_length:]
    x_tensor = torch.tensor(x_current, dtype=torch.float32).unsqueeze(0)

    with torch.no_grad():
        out = model(x_tensor)
        current_prob = torch.sigmoid(out["threat_logits"][:, 0]).item()
        current_stage_idx = int(out["stage_logits"].argmax(dim=1).item())
        stage_probs = torch.softmax(out["stage_logits"], dim=1).squeeze(0).numpy()
        confidence = float(stage_probs[current_stage_idx])

    # K-step autoregressive rollout for the forecast timeline
    pred_states, threat_probs, final_stage_logits = model.autoregressive_rollout(x_tensor, steps=steps)
    threat_timeline = threat_probs.squeeze(0).numpy().tolist()
    final_stage_idx = int(final_stage_logits.argmax(dim=1).item())

    # progression: current -> intermediate inferred stages (nearest-class
    # at each rollout step) -> final predicted stage. We derive
    # intermediate stages by re-running the stage head on each rolled-out
    # state's own encode() pass for a step-by-step trajectory.
    progression = [ATTACK_STAGES[current_stage_idx]]
    with torch.no_grad():
        rolling_seq = x_tensor.clone()
        for step in range(steps):
            step_out = model(rolling_seq)
            step_stage_idx = int(step_out["stage_logits"].argmax(dim=1).item())
            progression.append(ATTACK_STAGES[step_stage_idx])
            next_state = step_out["next_state"]
            rolling_seq = torch.cat([rolling_seq[:, 1:, :], next_state.unsqueeze(1)], dim=1)
    # collapse consecutive duplicate stages for a readable progression string
    collapsed = [progression[0]]
    for s in progression[1:]:
        if s != collapsed[-1]:
            collapsed.append(s)

    # explainability: background = a sample of earlier windows for SHAP,
    # falls back to occlusion automatically if shap isn't installed / too
    # few background samples exist.
    background = None
    if scaled_matrix.shape[0] > seq_cfg.sequence_length + 10:
        bg_candidates = []
        for _ in range(min(20, scaled_matrix.shape[0] - seq_cfg.sequence_length)):
            i = np.random.randint(0, scaled_matrix.shape[0] - seq_cfg.sequence_length)
            bg_candidates.append(scaled_matrix[i:i + seq_cfg.sequence_length].flatten())
        background = np.array(bg_candidates)

    top_features = explain_alert(model, x_current, background=background, top_k=5,
                                  use_shap=(background is not None))
    latest_state = state_matrix[-1]
    feature_index = {name: i for i, name in enumerate(FEATURE_VECTOR_ORDER)}
    for feature in top_features:
        index = feature_index[feature["feature"]]
        feature["current_value"] = round(float(latest_state[index]), 4)

    current_window_records = raw_windows[-1] if raw_windows else []
    flows = suspicious_flows(current_window_records, top_k=5)

    severity = DEFAULT_ALERT.severity(current_prob)
    attack_type = "Unknown"
    attack_type_confidence = 0.0
    if attack_classifier is not None:
        attack_type = str(attack_classifier.predict(state_matrix[-1:].astype(np.float64))[0])
        if hasattr(attack_classifier, "predict_proba"):
            attack_type_confidence = float(np.max(attack_classifier.predict_proba(
                state_matrix[-1:].astype(np.float64)
            )[0]))

    # The predicted-stage head and the threat-probability head are trained
    # jointly but can disagree in an undertrained or low-data model (e.g.
    # HIGH probability with a BENIGN stage label). Word the recommendation
    # around whichever non-benign stage is actually present in the
    # progression, and fall back to a probability-only phrasing rather
    # than asserting a "benign trajectory" is worth investigating.
    non_benign_stages = [s for s in collapsed if s != "BENIGN"]
    trajectory_label = non_benign_stages[-1].replace("_", " ").lower() if non_benign_stages else None

    recommendations = {
        "LOW": "Continue routine monitoring; no immediate action required.",
        "MEDIUM": "Review flagged flows; consider increasing capture granularity.",
        "HIGH": (f"Investigate the predicted {trajectory_label} trajectory."
                 if trajectory_label else
                 "Threat probability is elevated despite no specific non-benign stage "
                 "being predicted — review flagged flows and consider more training data."),
        "CRITICAL": (f"Immediate investigation recommended — trajectory points toward "
                      f"{trajectory_label}. Isolate suspicious hosts if confirmed."
                      if trajectory_label else
                      "Threat probability is critical despite no specific non-benign stage "
                      "being predicted — treat as a high-priority anomaly and investigate "
                      "flagged flows immediately."),
    }

    return {
        "input": input_path,
        "window_seconds": window_cfg.window_seconds,
        "forecast_steps": steps,
        "current_threat_probability": round(current_prob, 4),
        "risk_level": severity,
        "predicted_stage": ATTACK_STAGES[current_stage_idx],
        "predicted_attack_type": attack_type,
        "attack_type_confidence": round(attack_type_confidence, 4),
        "confidence": round(confidence, 4),
        "forecast_timeline": [
            {"offset_seconds": (i + 1) * window_cfg.window_seconds, "probability": round(p, 4)}
            for i, p in enumerate(threat_timeline)
        ],
        "attack_progression": collapsed,
        "top_features": top_features,
        "suspicious_flows": flows,
        "recommendation": recommendations[severity],
        "feature_availability": availability,
        "total_windows_observed": int(state_matrix.shape[0]),
        "current_features": {
            name: round(float(value), 4)
            for name, value in zip(FEATURE_VECTOR_ORDER, latest_state)
        },
    }


def main():
    parser = argparse.ArgumentParser(description="Forecast future attack progression from traffic.")
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--pcap", help="Path to a .pcap/.pcapng capture file.")
    src.add_argument("--csv", help="Path to a flow CSV file.")
    parser.add_argument("--steps", type=int, default=None, help="Forecast horizon override.")
    parser.add_argument("--run-name", default="default", help="Which trained model artifacts to use.")
    args = parser.parse_args()

    input_path = args.pcap or args.csv
    try:
        result = run_forecast(input_path, run_name=args.run_name, steps=args.steps)
    except (ForecasterNotTrainedError, PacketParseError, ValueError) as e:
        logger.error(str(e))
        sys.exit(1)

    import json
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
