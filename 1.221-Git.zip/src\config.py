"""
config.py
=========
Single source of truth for every tunable parameter in the pipeline.
Nothing in the rest of the codebase should hard-code a magic number that
belongs here — import from this module instead so behaviour stays
consistent across preprocessing, training, and inference.

All paths are relative to the project root and are created on first use.
"""

from __future__ import annotations
import os
from dataclasses import dataclass, field
from typing import List, Dict

# --------------------------------------------------------------------------
# Project paths
# --------------------------------------------------------------------------
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

PATHS = {
    "data_raw": os.path.join(PROJECT_ROOT, "data", "raw"),
    "data_processed": os.path.join(PROJECT_ROOT, "data", "processed"),
    "models": os.path.join(PROJECT_ROOT, "models", "checkpoints"),
    "scalers": os.path.join(PROJECT_ROOT, "models", "scalers"),
    "configs": os.path.join(PROJECT_ROOT, "configs"),
    "reports": os.path.join(PROJECT_ROOT, "reports"),
    "captures": os.path.join(PROJECT_ROOT, "captures"),
}

for _p in PATHS.values():
    os.makedirs(_p, exist_ok=True)


# --------------------------------------------------------------------------
# Windowing / state construction
# --------------------------------------------------------------------------
@dataclass
class WindowConfig:
    window_seconds: int = 10          # size of each time-window state S(t)
    stride_seconds: int = 10          # hop between successive windows (10 = non-overlapping)
    min_packets_per_window: int = 1   # windows with fewer packets are still emitted (zero-padded)


# --------------------------------------------------------------------------
# Sequence / world-model configuration
# --------------------------------------------------------------------------
@dataclass
class SequenceConfig:
    sequence_length: int = 12         # number of past states S(t-11..t) fed to the LSTM
    forecast_horizon: int = 5         # K future steps to simulate autoregressively


@dataclass
class ModelConfig:
    hidden_size: int = 128
    num_lstm_layers: int = 2
    dropout: float = 0.3
    learning_rate: float = 1e-3
    batch_size: int = 64
    epochs: int = 30
    early_stopping_patience: int = 5
    weight_decay: float = 1e-5
    # number of behavioural/attack classes the stage head predicts.
    # Index 0 is always reserved for BENIGN.
    num_stage_classes: int = 15


# --------------------------------------------------------------------------
# Attack-stage taxonomy (MITRE ATT&CK aligned, probabilistic mapping only)
# --------------------------------------------------------------------------
ATTACK_STAGES: List[str] = [
    "BENIGN",
    "RECONNAISSANCE",
    "RESOURCE_DEVELOPMENT",
    "INITIAL_ACCESS",
    "EXECUTION",
    "PERSISTENCE",
    "PRIVILEGE_ESCALATION",
    "DEFENSE_EVASION",
    "CREDENTIAL_ACCESS",
    "DISCOVERY",
    "LATERAL_MOVEMENT",
    "COLLECTION",
    "COMMAND_AND_CONTROL",
    "EXFILTRATION",
    "IMPACT",
]
assert len(ATTACK_STAGES) == ModelConfig().num_stage_classes

STAGE_TO_INDEX: Dict[str, int] = {s: i for i, s in enumerate(ATTACK_STAGES)}
INDEX_TO_STAGE: Dict[int, str] = {i: s for s, i in STAGE_TO_INDEX.items()}


# --------------------------------------------------------------------------
# Feature schema
# --------------------------------------------------------------------------
# These are the columns produced by feature_extraction.py for a single
# packet, BEFORE windowing/aggregation. Not every dataset adapter will be
# able to populate every field (e.g. flow-only CSVs have no per-packet TTL
# variance) — missing fields are filled with 0.0 and flagged in the
# feature-availability report so results are never silently fabricated.
PACKET_FEATURES: List[str] = [
    "timestamp", "src_ip", "dst_ip", "src_port", "dst_port", "protocol",
    "tcp_flags", "ttl", "tcp_window", "ip_frag", "payload_size",
    "packet_length", "iat", "is_retransmission",
]

# Aggregated per-window numeric feature vector — this is what the LSTM
# actually consumes. Order matters: it is fixed at FEATURE_VECTOR_ORDER
# and every dataset adapter must emit vectors in this exact order.
FEATURE_VECTOR_ORDER: List[str] = [
    "packet_count",
    "byte_count",
    "mean_packet_length",
    "std_packet_length",
    "mean_iat",
    "std_iat",
    "max_iat",
    "syn_count",
    "syn_rate",
    "fin_count",
    "rst_count",
    "ack_count",
    "psh_count",
    "urg_count",
    "unique_src_ips",
    "unique_dst_ips",
    "unique_src_ports",
    "unique_dst_ports",
    "unique_dst_ports_per_src",   # scan signature
    "connection_frequency",
    "retransmission_rate",
    "mean_ttl",
    "std_ttl",
    "mean_tcp_window",
    "frag_ratio",
    "bidir_packet_ratio",
    "bidir_byte_ratio",
    "tcp_ratio",
    "udp_ratio",
    "icmp_ratio",
    "mean_payload_size",
    "std_payload_size",
    "port_entropy",             # sequential vs random port access behaviour
    "duration",
]

FEATURE_DIM = len(FEATURE_VECTOR_ORDER)


# --------------------------------------------------------------------------
# Evaluation / alerting thresholds
# --------------------------------------------------------------------------
@dataclass
class AlertConfig:
    risk_low: float = 0.25
    risk_medium: float = 0.5
    risk_high: float = 0.75
    # risk >= risk_high -> "CRITICAL"

    def severity(self, prob: float) -> str:
        if prob < self.risk_low:
            return "LOW"
        if prob < self.risk_medium:
            return "MEDIUM"
        if prob < self.risk_high:
            return "HIGH"
        return "CRITICAL"


DEFAULT_WINDOW = WindowConfig()
DEFAULT_SEQUENCE = SequenceConfig()
DEFAULT_MODEL = ModelConfig()
DEFAULT_ALERT = AlertConfig()

RANDOM_SEED = 42
