#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 is required. Install it with: sudo apt install -y python3 python3-venv python3-pip" >&2
    exit 1
fi

if command -v apt-get >/dev/null 2>&1; then
    echo "[1/4] Installing Kali/Debian system packages..."
    sudo apt-get update
    sudo apt-get install -y python3-venv python3-pip tshark
else
    echo "[1/4] Non-Debian system detected; skipping apt packages."
fi

echo "[2/4] Creating virtual environment..."
python3 -m venv .venv

echo "[3/4] Installing Python dependencies..."
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt

echo "[4/4] Preparing launcher..."
chmod +x attack-forecaster
mkdir -p data/raw captures reports

cat <<'EOF'

Installation complete.

Run the terminal monitor:
  ./attack-forecaster demo

Run the local dashboard:
  ./attack-forecaster dashboard

Show all commands:
  ./attack-forecaster help
EOF
