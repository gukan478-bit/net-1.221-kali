"""
train.py
========
End-to-end training entry point.

Usage:
    python3 train.py --dataset cic-ids2018 --data-dir data/raw/cic-ids2018
    python3 train.py --dataset unsw-nb15 --data-dir data/raw/unsw --epochs 20
    python3 train.py --pcap captures/mixed_traffic.pcap --window 10

Steps performed:
  1. Load raw records (CSV via dataset_loaders, or PCAP via feature_extraction)
  2. Window into state vectors (windowing.py) — chronologically ordered
  3. Attach binary + stage labels per window from record labels
  4. Chronological train/val/test split (preprocessing.chronological_split)
  5. Fit scaler on TRAIN ONLY, transform all splits
  6. Build sequences (X, Y_states, Y_binary, Y_stage) per split
  7. Train NetworkWorldModel (LSTM) with early stopping on val loss
  8. Train BaselineLogisticModel on the same train split
  9. Save model checkpoint, scaler, and training config to models/
  10. Report where train/val/test metrics ended up (evaluate.py does the
      detailed comparison table)
"""

from __future__ import annotations
import argparse
import logging
import os
import sys
import time
from collections import Counter
from typing import List, Dict, Any, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import (
    PATHS, DEFAULT_WINDOW, DEFAULT_SEQUENCE, DEFAULT_MODEL, RANDOM_SEED,
    STAGE_TO_INDEX, WindowConfig, SequenceConfig, ModelConfig,
)
from feature_extraction import extract, PacketParseError
from dataset_loaders import load_dataset, DATASET_ADAPTERS
from windowing import build_state_sequence, report_feature_availability
from preprocessing import (
    StandardScaler, chronological_split, build_sequences, label_to_stage_index,
    normalize_attack_category, save_json,
)
from world_model import NetworkWorldModel
from baseline_model import BaselineLogisticModel

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("train")

torch.manual_seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)


def derive_window_labels(raw_windows: List[List[Dict[str, Any]]]) -> Tuple[np.ndarray, np.ndarray]:
    """
    For each window's raw records, derive:
      - binary label: 1 if ANY record in the window carries a non-benign
        label (majority-vote would hide short attack bursts inside longer
        benign windows, so we use max/any instead)
      - stage label: the most frequent non-benign stage index among the
        window's records (falls back to BENIGN=0 if none found)
    Records without a 'label' field (raw live PCAP capture, no ground
    truth) yield all-BENIGN labels — appropriate since such captures are
    for inference, not training.
    """
    binary_labels = np.zeros(len(raw_windows), dtype=np.float32)
    stage_labels = np.zeros(len(raw_windows), dtype=np.int64)
    unmapped_labels_seen = Counter()

    for i, recs in enumerate(raw_windows):
        if not recs:
            continue
        stage_votes = Counter()
        any_attack = False
        for r in recs:
            raw_label = r.get("label", "BENIGN")
            if str(raw_label).strip().lower() in ("1", "attack", "malicious"):
                any_attack = True
                category = str(r.get("attack_cat", "generic")).strip()
                idx = label_to_stage_index(category)
                if idx != -1 and idx != STAGE_TO_INDEX["BENIGN"]:
                    stage_votes[idx] += 1
                continue
            idx = label_to_stage_index(raw_label)
            if idx == -1:
                unmapped_labels_seen[raw_label] += 1
                continue
            if idx != STAGE_TO_INDEX["BENIGN"]:
                any_attack = True
                stage_votes[idx] += 1
        binary_labels[i] = 1.0 if any_attack else 0.0
        stage_labels[i] = stage_votes.most_common(1)[0][0] if stage_votes else STAGE_TO_INDEX["BENIGN"]

    if unmapped_labels_seen:
        logger.warning(
            "Encountered %d unmapped label values (showing top 5): %s. "
            "Extend preprocessing.LABEL_TO_STAGE to include these.",
            sum(unmapped_labels_seen.values()), unmapped_labels_seen.most_common(5)
        )
    return binary_labels, stage_labels


def derive_attack_categories(raw_windows: List[List[Dict[str, Any]]]) -> np.ndarray:
    """Choose the dominant UNSW/CIC attack family for each window."""
    categories = []
    benign = {"", "normal", "benign", "0"}
    for recs in raw_windows:
        votes = Counter()
        for record in recs:
            category = normalize_attack_category(
                record.get("attack_cat", record.get("label", "Normal"))
            )
            if category.lower() not in benign:
                votes[category] += 1
        categories.append(votes.most_common(1)[0][0] if votes else "Normal")
    return np.asarray(categories, dtype=str)


def train_world_model(X_train, Y_states_train, Y_binary_train, Y_stage_train,
                       X_val, Y_states_val, Y_binary_val, Y_stage_val,
                       model_cfg: ModelConfig, seq_cfg: SequenceConfig,
                       feature_dim: int) -> Tuple[NetworkWorldModel, Dict[str, Any]]:
    device = torch.device("cpu")  # CPU-only per project requirements
    model = NetworkWorldModel(feature_dim=feature_dim, model_cfg=model_cfg, seq_cfg=seq_cfg).to(device)

    opt = torch.optim.Adam(model.parameters(), lr=model_cfg.learning_rate,
                            weight_decay=model_cfg.weight_decay)
    bce = nn.BCEWithLogitsLoss()
    ce = nn.CrossEntropyLoss()
    mse = nn.MSELoss()

    def to_tensor(*arrs):
        return [torch.tensor(a, dtype=torch.float32 if a.dtype != np.int64 else torch.long) for a in arrs]

    Xt, Yst, Ybt, Ygt = to_tensor(X_train, Y_states_train, Y_binary_train, Y_stage_train)
    train_ds = TensorDataset(Xt, Yst, Ybt, Ygt)
    train_loader = DataLoader(train_ds, batch_size=model_cfg.batch_size, shuffle=True)

    Xv, Ysv, Ybv, Ygv = to_tensor(X_val, Y_states_val, Y_binary_val, Y_stage_val)

    best_val_loss = float("inf")
    best_state = None
    patience_counter = 0
    history = {"train_loss": [], "val_loss": []}

    for epoch in range(model_cfg.epochs):
        model.train()
        epoch_losses = []
        for xb, ysb, ybb, ygb in train_loader:
            opt.zero_grad()
            out = model(xb)
            # threat loss: supervise each of the K forecast steps
            loss_threat = bce(out["threat_logits"], ybb)
            # stage loss: predicted at horizon K
            loss_stage = ce(out["stage_logits"], ygb)
            # next-state regression loss (single-step, teacher-forced)
            loss_state = mse(out["next_state"], ysb[:, 0, :])
            loss = loss_threat + loss_stage + 0.5 * loss_state
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            opt.step()
            epoch_losses.append(loss.item())

        model.eval()
        with torch.no_grad():
            out_v = model(Xv)
            vl_threat = bce(out_v["threat_logits"], Ybv)
            vl_stage = ce(out_v["stage_logits"], Ygv)
            vl_state = mse(out_v["next_state"], Ysv[:, 0, :])
            val_loss = (vl_threat + vl_stage + 0.5 * vl_state).item()

        train_loss = float(np.mean(epoch_losses))
        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        logger.info("Epoch %d/%d — train_loss=%.4f val_loss=%.4f",
                    epoch + 1, model_cfg.epochs, train_loss, val_loss)

        if val_loss < best_val_loss - 1e-4:
            best_val_loss = val_loss
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
            patience_counter = 0
        else:
            patience_counter += 1
            if patience_counter >= model_cfg.early_stopping_patience:
                logger.info("Early stopping at epoch %d (no val improvement for %d epochs).",
                            epoch + 1, model_cfg.early_stopping_patience)
                break

    if best_state is not None:
        model.load_state_dict(best_state)

    return model, history


def main():
    parser = argparse.ArgumentParser(description="Train the AI network attack forecaster.")
    src_group = parser.add_mutually_exclusive_group(required=True)
    src_group.add_argument("--dataset", choices=list(DATASET_ADAPTERS.keys()),
                            help="Named public dataset adapter to use.")
    src_group.add_argument("--pcap", help="Path to a labeled/unlabeled PCAP for training data.")
    src_group.add_argument("--csv", help="Path to a single flow CSV for training data.")
    parser.add_argument("--data-dir", help="Directory containing dataset CSVs (used with --dataset).")
    parser.add_argument("--window", type=int, default=DEFAULT_WINDOW.window_seconds)
    parser.add_argument("--sequence-length", type=int, default=DEFAULT_SEQUENCE.sequence_length)
    parser.add_argument("--forecast-steps", type=int, default=DEFAULT_SEQUENCE.forecast_horizon)
    parser.add_argument("--epochs", type=int, default=DEFAULT_MODEL.epochs)
    parser.add_argument("--batch-size", type=int, default=DEFAULT_MODEL.batch_size)
    parser.add_argument("--run-name", default="default")
    args = parser.parse_args()

    # 1. Load raw records
    t0 = time.time()
    if args.dataset:
        if not args.data_dir:
            parser.error("--dataset requires --data-dir")
        logger.info("Loading dataset '%s' from %s", args.dataset, args.data_dir)
        records = load_dataset(args.dataset, args.data_dir)
    elif args.pcap:
        records = extract(args.pcap)
    else:
        records = extract(args.csv)

    if not records:
        logger.error("No records extracted — nothing to train on. Aborting.")
        sys.exit(1)
    logger.info("Loaded %d raw records in %.1fs", len(records), time.time() - t0)

    availability = report_feature_availability(records)
    logger.info("Feature availability for this input source: %s", availability)

    # 2. Window
    window_cfg = WindowConfig(window_seconds=args.window, stride_seconds=args.window)
    state_matrix, raw_windows, start_times = build_state_sequence(records, window_cfg)
    logger.info("Built %d windows of %ds each", len(state_matrix), window_cfg.window_seconds)
    if len(state_matrix) < (args.sequence_length + args.forecast_steps) * 3:
        logger.warning(
            "Very few windows (%d) relative to sequence_length+forecast_steps (%d). "
            "Results will be unreliable; provide more data.",
            len(state_matrix), args.sequence_length + args.forecast_steps
        )

    # 3. Labels
    binary_labels, stage_labels = derive_window_labels(raw_windows)
    attack_categories = derive_attack_categories(raw_windows)
    logger.info("Label distribution — attack windows: %d/%d (%.1f%%)",
                int(binary_labels.sum()), len(binary_labels),
                100 * binary_labels.mean() if len(binary_labels) else 0.0)

    # 4. Chronological split (on windows, before sequencing)
    (tr_s, tr_e), (va_s, va_e), (te_s, te_e) = chronological_split(len(state_matrix))
    logger.info("Chronological split — train[%d:%d] val[%d:%d] test[%d:%d]",
                tr_s, tr_e, va_s, va_e, te_s, te_e)

    # 5. Fit scaler on TRAIN ONLY
    scaler = StandardScaler()
    scaler.fit(state_matrix[tr_s:tr_e])
    scaled_matrix = scaler.transform(state_matrix)

    seq_cfg = SequenceConfig(sequence_length=args.sequence_length, forecast_horizon=args.forecast_steps)
    model_cfg = ModelConfig(epochs=args.epochs, batch_size=args.batch_size)

    def build_split(s, e):
        # sequences are built only from within this split's index range,
        # so no window that spans the split boundary is ever included.
        return build_sequences(
            scaled_matrix[s:e], stage_labels=stage_labels[s:e],
            binary_labels=binary_labels[s:e], seq_cfg=seq_cfg,
        )

    train_seqs = build_split(tr_s, tr_e)
    val_seqs = build_split(va_s, va_e)
    test_seqs = build_split(te_s, te_e)

    for name, d in [("train", train_seqs), ("val", val_seqs), ("test", test_seqs)]:
        logger.info("%s sequences: %s", name, d["X"].shape if "X" in d else "EMPTY")

    if any(d["X"].shape[0] == 0 for d in (train_seqs, val_seqs, test_seqs)):
        logger.error(
            "At least one chronological split has zero sequences. Each of the "
            "70%% train, 15%% validation, and final 15%% test partitions needs "
            "at least sequence_length + forecast_horizon = %d windows. "
            "Use more data, a smaller window, or shorter sequence/forecast settings.",
            args.sequence_length + args.forecast_steps
        )
        sys.exit(1)

    # 6/7. Train LSTM world model
    model, history = train_world_model(
        train_seqs["X"], train_seqs["Y_states"], train_seqs["Y_binary"], train_seqs["Y_stage"],
        val_seqs["X"], val_seqs["Y_states"], val_seqs["Y_binary"], val_seqs["Y_stage"],
        model_cfg=model_cfg, seq_cfg=seq_cfg, feature_dim=scaled_matrix.shape[1],
    )

    # 8. Train baseline
    logger.info("Training Logistic Regression baseline...")
    baseline = BaselineLogisticModel()
    # baseline predicts immediate-next-window label (first forecast step)
    baseline.fit(train_seqs["X"], train_seqs["Y_binary"][:, 0])

    # A shallow, interpretable classifier preserves the dataset's native
    # attack-family labels (e.g. Exploits, Fuzzers, Generic, DoS) for the
    # dashboard; the LSTM remains responsible for temporal risk forecasting.
    attack_classifier = None
    attack_classes = []
    try:
        from sklearn.ensemble import RandomForestClassifier
        attack_classifier = RandomForestClassifier(
            n_estimators=160, random_state=RANDOM_SEED, class_weight="balanced_subsample",
            n_jobs=-1, min_samples_leaf=2,
        )
        attack_classifier.fit(state_matrix[tr_s:tr_e], attack_categories[tr_s:tr_e])
        attack_classes = list(attack_classifier.classes_)
    except ValueError as exc:
        logger.warning("Attack-family classifier not saved: %s", exc)

    # 9. Save artifacts
    run_dir = os.path.join(PATHS["models"], args.run_name)
    os.makedirs(run_dir, exist_ok=True)
    torch.save(model.state_dict(), os.path.join(run_dir, "world_model.pt"))
    scaler.save(os.path.join(PATHS["scalers"], f"{args.run_name}_scaler.pkl"))

    import pickle
    with open(os.path.join(run_dir, "baseline_model.pkl"), "wb") as f:
        pickle.dump(baseline, f)
    if attack_classifier is not None:
        with open(os.path.join(run_dir, "attack_classifier.pkl"), "wb") as f:
            pickle.dump(attack_classifier, f)

    save_json({
        "window_seconds": window_cfg.window_seconds,
        "sequence_length": seq_cfg.sequence_length,
        "forecast_horizon": seq_cfg.forecast_horizon,
        "feature_dim": int(scaled_matrix.shape[1]),
        "num_windows": int(len(state_matrix)),
        "split_indices": {"train": [tr_s, tr_e], "val": [va_s, va_e], "test": [te_s, te_e]},
        "feature_availability": availability,
        "training_history": history,
        "source": args.dataset or args.pcap or args.csv,
        "attack_classes": attack_classes,
    }, os.path.join(run_dir, "run_config.json"))

    # stash test sequences so evaluate.py can reuse them without re-parsing
    np.savez(
        os.path.join(run_dir, "test_sequences.npz"),
        X=test_seqs["X"],
        Y_states=test_seqs.get("Y_states", np.zeros((0,))),
        Y_binary=test_seqs.get("Y_binary", np.zeros((0,))),
        Y_stage=test_seqs.get("Y_stage", np.zeros((0,))),
        attack_features=state_matrix[
            te_s + args.sequence_length + args.forecast_steps - 1:te_e
        ],
        attack_categories=attack_categories[
            te_s + args.sequence_length + args.forecast_steps - 1:te_e
        ],
    )

    logger.info("Training complete. Artifacts saved to %s", run_dir)
    logger.info("Run evaluate.py --run-name %s for the full metrics comparison.", args.run_name)


if __name__ == "__main__":
    main()
