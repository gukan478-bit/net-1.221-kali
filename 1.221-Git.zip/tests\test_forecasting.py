"""
test_forecasting.py
====================
Tests preprocessing (chronological split, scaler leakage prevention,
sequence construction) and the world model's K-step autoregressive
rollout shape/behaviour.
"""

import os
import sys
import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from config import FEATURE_DIM, SequenceConfig, ModelConfig
from preprocessing import (
    StandardScaler, chronological_split, build_sequences, label_to_stage_index,
    normalize_attack_category,
)
from world_model import NetworkWorldModel


def test_chronological_split_is_ordered_and_non_overlapping():
    n = 100
    (tr_s, tr_e), (va_s, va_e), (te_s, te_e) = chronological_split(n, train_frac=0.7, val_frac=0.15)
    assert tr_s == 0
    assert tr_e == va_s
    assert va_e == te_s
    assert te_e == n
    assert tr_e == 70
    assert va_e == 85


def test_scaler_fit_only_on_train_does_not_use_test_stats():
    rng = np.random.RandomState(0)
    train_data = rng.normal(loc=0.0, scale=1.0, size=(100, 5))
    test_data = rng.normal(loc=1000.0, scale=50.0, size=(20, 5))  # wildly different distribution

    scaler = StandardScaler()
    scaler.fit(train_data)  # fit ONLY on train

    # scaler's learned mean should reflect train_data, NOT test_data
    assert np.allclose(scaler.mean_, train_data.mean(axis=0), atol=1e-6)
    assert not np.allclose(scaler.mean_, test_data.mean(axis=0), atol=10)

    # transforming test data with train-fit scaler should NOT re-center it near zero
    # (proves the scaler wasn't secretly re-fit on test data)
    transformed_test = scaler.transform(test_data)
    assert transformed_test.mean() > 5.0  # still far from 0 because scaler is train-based


def test_build_sequences_shapes():
    n_windows, feat_dim = 50, FEATURE_DIM
    state_matrix = np.random.randn(n_windows, feat_dim).astype(np.float32)
    binary_labels = np.random.randint(0, 2, size=n_windows).astype(np.float32)
    stage_labels = np.random.randint(0, 15, size=n_windows).astype(np.int64)

    seq_cfg = SequenceConfig(sequence_length=10, forecast_horizon=5)
    result = build_sequences(state_matrix, stage_labels, binary_labels, seq_cfg)

    expected_n = n_windows - seq_cfg.sequence_length - seq_cfg.forecast_horizon + 1
    assert result["X"].shape == (expected_n, seq_cfg.sequence_length, feat_dim)
    assert result["Y_states"].shape == (expected_n, seq_cfg.forecast_horizon, feat_dim)
    assert result["Y_binary"].shape == (expected_n, seq_cfg.forecast_horizon)
    assert result["Y_stage"].shape == (expected_n,)


def test_build_sequences_no_boundary_crossing():
    """A sequence built from a 20-window split with seq_len=10, horizon=5
    must never require windows beyond index 19 (the split's own end)."""
    n_windows = 20
    state_matrix = np.arange(n_windows * FEATURE_DIM).reshape(n_windows, FEATURE_DIM).astype(np.float32)
    seq_cfg = SequenceConfig(sequence_length=10, forecast_horizon=5)
    result = build_sequences(state_matrix, np.zeros(n_windows, dtype=np.int64),
                              np.zeros(n_windows, dtype=np.float32), seq_cfg)
    # last valid start = n_windows - seq_len - horizon = 5 -> sequences use indices up to 19
    assert result["X"].shape[0] == 6  # starts 0..5 inclusive


def test_label_to_stage_index_known_and_unknown():
    from config import STAGE_TO_INDEX
    assert label_to_stage_index("BENIGN") == STAGE_TO_INDEX["BENIGN"]
    assert label_to_stage_index("PortScan") == STAGE_TO_INDEX["RECONNAISSANCE"]
    assert label_to_stage_index("DDoS") == STAGE_TO_INDEX["IMPACT"]
    assert label_to_stage_index("SomeTotallyUnknownLabelXYZ123") == -1


def test_attack_category_normalization_covers_requested_families():
    assert normalize_attack_category("DDoS") == "DDoS/DoS"
    assert normalize_attack_category("DoS Hulk") == "DDoS/DoS"
    assert normalize_attack_category("SSH-Bruteforce") == "Brute Force"
    assert normalize_attack_category("FTP-Patator") == "Brute Force"


def test_world_model_forward_shapes():
    seq_cfg = SequenceConfig(sequence_length=8, forecast_horizon=4)
    model_cfg = ModelConfig(hidden_size=16, num_lstm_layers=1, epochs=1)
    model = NetworkWorldModel(feature_dim=FEATURE_DIM, model_cfg=model_cfg, seq_cfg=seq_cfg)

    batch = 3
    x = torch.randn(batch, seq_cfg.sequence_length, FEATURE_DIM)
    out = model(x)

    assert out["threat_logits"].shape == (batch, seq_cfg.forecast_horizon)
    assert out["stage_logits"].shape == (batch, model_cfg.num_stage_classes)
    assert out["next_state"].shape == (batch, FEATURE_DIM)


def test_world_model_autoregressive_rollout_shapes():
    seq_cfg = SequenceConfig(sequence_length=8, forecast_horizon=4)
    model_cfg = ModelConfig(hidden_size=16, num_lstm_layers=1, epochs=1)
    model = NetworkWorldModel(feature_dim=FEATURE_DIM, model_cfg=model_cfg, seq_cfg=seq_cfg)

    batch = 2
    x = torch.randn(batch, seq_cfg.sequence_length, FEATURE_DIM)
    states, probs, stage_logits = model.autoregressive_rollout(x, steps=6)

    assert states.shape == (batch, 6, FEATURE_DIM)
    assert probs.shape == (batch, 6)
    assert stage_logits.shape == (batch, model_cfg.num_stage_classes)
    assert torch.all(probs >= 0) and torch.all(probs <= 1)  # valid probabilities
