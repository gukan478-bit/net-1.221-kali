"""Local Streamlit dashboard for offline and live Kali Linux traffic analysis."""

from __future__ import annotations

import os
import subprocess
import tempfile
from datetime import datetime

import pandas as pd
import streamlit as st

from config import PATHS, WindowConfig
from feature_extraction import extract, PacketParseError
from forecast import ForecasterNotTrainedError, run_forecast
from windowing import build_state_sequence


st.set_page_config(page_title="Network attack monitor", layout="wide")
st.title("Network attack monitor")
st.caption("Local-only UNSW-NB15 model inference and Kali Linux capture telemetry.")


def capture_with_tshark(interface: str, seconds: int) -> str:
    """Capture one bounded PCAP snapshot without invoking a shell."""
    os.makedirs(PATHS["captures"], exist_ok=True)
    path = os.path.join(
        PATHS["captures"], f"live_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pcapng"
    )
    command = ["tshark", "-i", interface, "-a", f"duration:{seconds}", "-w", path]
    try:
        completed = subprocess.run(command, capture_output=True, text=True, timeout=seconds + 15)
    except FileNotFoundError as exc:
        raise RuntimeError("tshark is not installed. On Kali: sudo apt install tshark") from exc
    if completed.returncode != 0:
        message = completed.stderr.strip() or "tshark returned a non-zero exit code"
        raise RuntimeError(message)
    return path


def interfaces():
    try:
        completed = subprocess.run(["tshark", "-D"], capture_output=True, text=True, timeout=10)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []
    names = []
    for line in completed.stdout.splitlines():
        if ". " in line:
            names.append(line.split(". ", 1)[1].split(" ", 1)[0])
    return names


def render_result(path: str, result: dict):
    records = extract(path)
    states, _, _ = build_state_sequence(records, WindowConfig(
        window_seconds=result["window_seconds"], stride_seconds=result["window_seconds"]
    ))
    latest = states[-1] if len(states) else [0] * 34
    columns = ["packets", "bytes", "mean_packet_length", "syn_count", "unique_sources",
               "unique_destinations", "tcp_ratio", "udp_ratio", "icmp_ratio"]
    values = [latest[0], latest[1], latest[2], latest[7], latest[14], latest[15],
              latest[27], latest[28], latest[29]]
    metrics = st.columns(5)
    metrics[0].metric("Threat probability", f"{result['current_threat_probability'] * 100:.1f}%")
    metrics[1].metric("Risk", result["risk_level"])
    metrics[2].metric("Attack family", result.get("predicted_attack_type", "Unknown"))
    metrics[3].metric("Packets", f"{int(values[0]):,}")
    metrics[4].metric("Bytes", f"{int(values[1]):,}")

    telemetry = pd.DataFrame([values], columns=columns)
    st.subheader("Current-window telemetry")
    st.bar_chart(telemetry.T.rename(columns={0: "value"}))
    timeline = pd.DataFrame(result["forecast_timeline"])
    timeline["probability_percent"] = timeline["probability"] * 100
    st.subheader("Threat forecast")
    st.line_chart(timeline.set_index("offset_seconds")["probability_percent"])
    st.write(f"**Predicted stage:** {result['predicted_stage'].replace('_', ' ').title()}  "
             f"({result['confidence'] * 100:.1f}% confidence)")
    st.write(f"**Recommendation:** {result['recommendation']}")
    if result.get("suspicious_flows"):
        st.subheader("Suspicious flows")
        st.dataframe(pd.DataFrame(result["suspicious_flows"]), use_container_width=True)


with st.sidebar:
    run_name = st.text_input(
        "Model run", os.environ.get("ATTACK_FORECASTER_DEFAULT_RUN", "demo_bundled")
    )
    steps = st.number_input("Forecast steps", min_value=1, max_value=20, value=5)
    st.header("Live capture")
    available = interfaces()
    interface = st.selectbox("Interface", available or ["eth0"])
    seconds = st.slider("Capture duration (seconds)", 5, 120, 15)
    capture_button = st.button("Capture and analyze", type="primary")
    st.header("Offline input")
    uploaded = st.file_uploader("Upload PCAP or flow CSV", type=["pcap", "pcapng", "cap", "csv"])
    upload_button = st.button("Analyze upload")

path = None
if capture_button:
    try:
        with st.spinner("Capturing local traffic..."):
            path = capture_with_tshark(interface, seconds)
    except RuntimeError as exc:
        st.error(str(exc))
if upload_button and uploaded is not None:
    suffix = os.path.splitext(uploaded.name)[1].lower() or ".pcap"
    handle = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    handle.write(uploaded.getbuffer())
    handle.close()
    path = handle.name

if path:
    try:
        with st.spinner("Extracting features and classifying traffic..."):
            result = run_forecast(path, run_name=run_name, steps=int(steps))
        render_result(path, result)
    except (ForecasterNotTrainedError, PacketParseError, ValueError) as exc:
        st.error(str(exc))
else:
    st.info("Train a model, then capture a bounded live snapshot or upload a capture.")
