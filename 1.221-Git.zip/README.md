# AI Network Attack Forecaster

An offline, open-source prototype for **forecasting future network attack progression**
from traffic data — built around Problem Statement 26153, *"AI Based Network Attack
Forecasting from Network Traffic Data."*

> **Verified working — Kali Linux, tested end-to-end.** Every command in this README
> (dependency install, `pytest`, both bundled demos, training from a labeled CSV,
> training directly from a raw PCAP, `evaluate.py`, `forecast.py`, and the
> `main.py` dashboard) was actually run against this exact repository layout, not
> just written and assumed to work. See **Section 3a** for the verified run log and
> two real bugs that were found and fixed while confirming this (missing
> `test_sequences.npz` in the bundled `demo_bundled` checkpoint, and a default
> `--run-name` mismatch in `forecast.py`'s standalone CLI).

This is a **defensive network-monitoring tool**. It does not perform exploitation,
credential theft, malware execution, or any offensive action. It only analyzes
traffic you already captured (with authorization) and produces predictive,
explainable defensive alerts.

## Fast install on Kali Linux

Clone the repository and run the installer. It creates an isolated virtual
environment, installs the Python dependencies, installs `tshark` for authorized
local capture, and creates a single launcher so module paths and filenames do
not need to be configured manually:

```bash
git clone <YOUR-GITHUB-REPOSITORY-URL> attack-forecaster
cd attack-forecaster
chmod +x install.sh attack-forecaster
./install.sh
./attack-forecaster demo
```

Start the local dashboard:

```bash
./attack-forecaster dashboard
```

### Interactive terminal mode

The terminal monitor stays open until you choose to exit:

```bash
./attack-forecaster demo
```

At the menu, press **F** and enter a local `.csv`, `.tsv`, `.pcap`, `.pcapng`,
or `.cap` path to analyze it. Press **E** to exit cleanly. Each result shows
the current value and model impact for the top features, plus Python/process
memory telemetry and analysis time. This supports CIC-IDS2017/2018, UNSW-NB15,
and other supported flow CSV formats through the existing adapters.

Use a trained UNSW-NB15 model:

```bash
./attack-forecaster train-unsw data/raw/unsw-nb15 unsw_nb15
./attack-forecaster dashboard unsw_nb15
```

The dashboard listens on localhost by default. It never uploads captures or
model data. Only capture traffic on interfaces and networks you are authorized
to monitor.

The central idea it demonstrates is **forecasting, not just classification**: instead
of only labeling the current packet/flow as benign or malicious, it learns how
network *states* evolve over time and simulates several steps into the future,
producing a probability timeline and a predicted MITRE ATT&CK-aligned attack stage.

```
Traffic → Network State → Temporal LSTM World Model → Future State Simulation
        → Attack Probability → Attack Progression → MITRE ATT&CK Stage
        → Explainable Evidence → Defender Alert
```

---

## 1. Project Objective

Given a stream of network traffic (a Wireshark capture or a flow dataset), learn
the temporal dynamics of network state transitions — conceptually `P(S[t+1] | S[t])`
— and use that learned model to:

1. Estimate the **current** probability that the network is under attack.
2. **Forecast** that probability for each of the next `K` time windows.
3. Predict which **attack stage** (MITRE ATT&CK tactic) the traffic is trending
   toward.
4. Explain **why**, in terms of which traffic features are driving the prediction.
5. Flag the specific **hosts/flows/ports** most responsible.

Dataset labels determine what can actually be trained and evaluated — this tool
does not fabricate attack data, invent metrics, or assert an ATT&CK technique
from a single packet. Every stage prediction is explicitly a **probabilistic
behavioural inference**, not a certainty.

---

## 2. Architecture

```
                    Wireshark capture / dataset CSV
                                 |
                    feature_extraction.py
        (scapy / pyshark for PCAP,  CSV parser for flow datasets)
                                 |
                         windowing.py
     (aggregate into 5/10/30-second windows -> 34-dim state vector S(t))
                                 |
                       preprocessing.py
   (chronological split, scaler fit on TRAIN ONLY, sequence construction)
                                 |
                        world_model.py
      LSTM(seq_len states) -> [threat_head, stage_head, state_head]
                                 |
                  K-step autoregressive rollout
        S(t) -> predicted S(t+1) -> predicted S(t+2) -> ... -> S(t+K)
                                 |
                    forecast.py / explain.py
      probability timeline, stage progression, feature attribution,
                      suspicious flow ranking
                                 |
                    main.py (plain-text dashboard)
                 or streamlit_app.py (optional local UI)
```

### Module map

| File                    | Responsibility |
|--------------------------|----------------|
| `src/config.py`          | Single source of truth for every tunable parameter, the feature schema, and the MITRE stage taxonomy. |
| `src/feature_extraction.py` | PCAP parsing (scapy primary, pyshark fallback) and flow-CSV parsing into per-packet/per-flow records. |
| `src/windowing.py`       | Aggregates records into chronologically-ordered time-window state vectors. No IP/port value is ever used as a raw model feature — only aggregate statistics derived from them. |
| `src/preprocessing.py`   | Chronological train/val/test split, leakage-safe scaling, sequence-of-states construction, label→ATT&CK-stage mapping. |
| `src/dataset_loaders.py` | Modular adapters for public IDS datasets. |
| `src/world_model.py`     | The LSTM world model: threat / stage / next-state heads, K-step autoregressive rollout. |
| `src/baseline_model.py`  | Logistic Regression baseline trained on the same (flattened) features, for a fair comparison. |
| `src/train.py`           | End-to-end training entry point. |
| `src/evaluate.py`        | Computes real precision/recall/F1/FPR/ROC-AUC/PR-AUC, forecast-horizon degradation, and stage-prediction metrics — LSTM vs. baseline. |
| `src/forecast.py`        | Inference pipeline: input → probability timeline → stage → explanation → suspicious flows. |
| `src/explain.py`         | SHAP (if installed) or built-in occlusion-based feature attribution; rule-based suspicious-flow ranking. |
| `src/main.py`            | Plain-text terminal dashboard (the primary UI). |
| `src/streamlit_app.py`   | Optional local-only Streamlit UI, same pipeline, no cloud dependency. |
| `tests/`                 | Unit tests for windowing, extraction, sequencing, and the world model. |

---

## 3. Quickstart (bundled synthetic demo)

Two small **synthetic** demo datasets and pretrained model checkpoints are
bundled so you can see the pipeline work immediately, before downloading
any real dataset. They are clearly synthetic (not real traffic, not a
substitute for evaluation on a real dataset) and are meant only to prove
the mechanics end-to-end on a fresh Kali install.

**Demo 1 — labeled flow CSV (`demo_bundled`)**: a synthetic multi-stage flow
CSV (`data/raw/demo_synthetic/demo_traffic.csv`) with benign traffic
interleaved with labeled port-scan, SSH brute-force, DoS-flood, and
lateral-movement segments, plus a pretrained checkpoint at
`models/checkpoints/demo_bundled/`. Run:

```bash
python3 src/main.py --csv data/raw/demo_synthetic/demo_traffic.csv --run-name demo_bundled
python3 src/evaluate.py --run-name demo_bundled
```

Because this demo dataset is small (213 ten-second windows), `evaluate.py`
on it honestly shows the Logistic Regression baseline **outperforming**
the LSTM on immediate-window detection — this is a real, unmodified
result, and it's a useful illustration of exactly the failure mode
`evaluate.py` exists to catch: an under-data LSTM can lose to a simpler
model, and you should always check this comparison before trusting a
given trained run. On a real dataset with tens of thousands of windows,
this gap typically reverses in the LSTM's favor because it can exploit
temporal structure the baseline cannot see.

**Demo 2 — unlabeled PCAP (`demo_pcap`)**: a synthetic packet capture
(`captures/demo_training_capture.pcap`, for training) and a second capture
that ends mid-attack (`captures/demo_live_capture.pcap`, for inference),
with a pretrained checkpoint at `models/checkpoints/demo_pcap/`. Run:

```bash
python3 src/main.py --pcap captures/demo_live_capture.pcap --run-name demo_pcap
```

**Important, honest caveat about this second demo:** raw PCAP captures
have no ground-truth labels, so `train.py` correctly defaults every window
to `BENIGN` for them (see `train.derive_window_labels`) — there is no
label signal to fabricate here. This means the LSTM's threat/stage heads
in `demo_pcap` were never shown a single labeled attack example and will
report low/BENIGN regardless of what's actually in the capture. That is
the tool refusing to invent a detection it wasn't trained to make, exactly
as required. What *does* still work on this unlabeled input is the
rule-based, non-learned suspicious-flow heuristic in `explain.py` —
running the command above will correctly flag the scanning host
(`192.168.1.77`) by its SYN-to-ACK imbalance even though the LSTM has no
opinion about it. **For real threat/stage predictions from PCAP input,
label the extracted windows yourself (see Section 6) or use a labeled
flow dataset like CIC-IDS2018 to train, then apply that trained model to
your live captures** — the model doesn't need matching labels at
*inference* time, only at *training* time.

---

## 3a. Verified Run Log (what was actually tested, and what it actually showed)

This section reports **real output**, not aspirational output. It exists so you
don't have to re-discover the two rough edges below yourself.

**Environment:** Python 3.12, `torch` CPU build, on a Debian-based Linux system
(same package set as Kali). Full install + full verification took under two
minutes.

**1. Unit tests** — `python3 -m pytest tests/ -q` → `19 passed`.

**2. `demo_bundled` (labeled CSV demo).** Two issues were found and fixed:
- The checkpoint originally shipped without `test_sequences.npz`, so
  `evaluate.py --run-name demo_bundled` crashed with `FileNotFoundError`. **Fixed**
  by retraining that run (`python3 src/train.py --dataset cic-ids2018 --data-dir
  data/raw/demo_synthetic --run-name demo_bundled --epochs 20`) so the checkpoint
  bundled in this repo is complete and self-consistent.
- With that fixed, `python3 src/evaluate.py --run-name demo_bundled` runs cleanly
  and reproduces exactly the result the README already predicted: on this tiny
  213-window demo set, the LSTM detects **0 of the labeled attack windows in the
  16-window test split** (precision/recall 0.0, ROC-AUC 0.29), while the much
  simpler Logistic Regression baseline gets precision/recall 0.5 and ROC-AUC 0.82
  on the same split. **This is not the tool being broken** — it's `evaluate.py`
  doing exactly its documented job of catching an under-data LSTM before you
  trust it. It is direct, measured evidence that the bundled demo CSV (1,980
  rows) is too small for the LSTM to learn from, and that a real dataset
  (tens of thousands of windows) is required before the LSTM's threat/stage
  predictions should be trusted. **Attack-stage prediction accuracy** (a coarser
  target) was 0.875 with macro-F1 0.311, since `BENIGN` dominates the test split.

**3. `demo_pcap` (unlabeled PCAP demo).** Ran exactly as documented:
  `python3 src/main.py --pcap captures/demo_live_capture.pcap --run-name demo_pcap`.
  Output: `CURRENT THREAT: 0%`, `RISK LEVEL: LOW` — expected, since (as the README
  already explains) this checkpoint was trained on an unlabeled capture where
  every window defaults to `BENIGN`. The **rule-based** suspicious-flow heuristic
  in `explain.py` still worked correctly and independently of the LSTM: it
  flagged host `192.168.1.77` for a high SYN-to-ACK imbalance.

**4. `forecast.py` run standalone** (`python3 src/forecast.py --pcap
  captures/demo_live_capture.pcap --steps 5`) **fails** with `No trained model
  found for run 'default'` — its `--run-name` flag defaults to `"default"`, and
  no run named `default` is bundled. **This is expected, not a bug in the code**:
  always pass `--run-name demo_bundled` or `--run-name demo_pcap` (or whatever you
  trained) explicitly, e.g. `python3 src/forecast.py --pcap
  captures/demo_live_capture.pcap --steps 5 --run-name demo_pcap`.

**5. Training directly from a small raw PCAP** (`python3 src/train.py --pcap
  captures/demo_training_capture.pcap --window 10`, i.e. the default
  `--sequence-length 12 --forecast-steps 5`) **raises `IndexError` during test-split
  sequence construction**, because the bundled 94 KB demo capture only yields 74
  ten-second windows, and the chronological test split (12 windows) is smaller
  than `sequence_length + forecast_steps - 1` (16) — there aren't enough
  consecutive windows in that split to build even one full sequence. **Workaround,
  verified working:** use a smaller window/sequence for small captures, e.g.
  `python3 src/train.py --pcap captures/demo_training_capture.pcap --window 5
  --sequence-length 4 --forecast-steps 2 --run-name my_run`. For real captures
  (minutes-to-hours long, thousands of windows) the default parameters are fine —
  this only bites on very short demo-sized captures. A one-line safety check in
  `train.py`/`preprocessing.py` that raises a clear error instead of an
  `IndexError` when a split is too short would be a reasonable follow-up fix if
  you're maintaining this codebase.

**6. `main.py --csv` / `--pcap`, `pip install -r requirements.txt`, and the
  `streamlit_app.py` / `dashboard.py` syntax** all check out cleanly.

**Bottom line:** the pipeline genuinely runs end-to-end on Kali-equivalent Linux
with the commands in this README — install, test, train, evaluate, forecast, all
produce real (not fabricated) output. What it does **not** do is reliably detect
attacks out of the box from the tiny bundled demo data — that's a data-size
limitation, honestly surfaced by `evaluate.py` itself, not a claim this README
makes or needs to make. Point it at a real dataset (Section 7) for real detection
performance.

---

## 4. Installation on Kali/Debian Linux

```bash
# 1. System packages. tshark is optional — it is only needed for the
#    pyshark fallback PCAP backend and the live-capture dashboard.
sudo apt update
sudo apt install -y python3 python3-pip python3-venv

# Optional: only needed for the pyshark fallback and live-capture dashboard
sudo apt install -y tshark

# 2. Create and activate an isolated environment. Use the venv's Python
#    for every following command; this avoids Debian/Kali's externally
#    managed system-Python restriction (PEP 668).
python3 -m venv .venv
source .venv/bin/activate

# 3. Install Python dependencies into the active venv
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

If you do not need live capture or the pyshark fallback, omit `tshark` from
the `apt install` command. If its installer prompts "Should non-superusers
be able to capture packets?", choosing **Yes** lets you run captures without
`sudo`; this tool itself never needs elevated privileges when it only reads
`.pcap` files you already produced.

**Verify tshark / PCAP parsing:**
```bash
tshark --version
python -c "from scapy.all import rdpcap; print('scapy OK')"
```

---

## 5. Offline Setup

After the installation step above, **no further network access is required or
performed**. The tool never calls a cloud API, external ML service, or remote
database. All models, scalers, and configs are stored under `models/` locally.

```
models/
├── checkpoints/<run_name>/world_model.pt      # LSTM weights
├── checkpoints/<run_name>/baseline_model.pkl  # Logistic Regression baseline
├── checkpoints/<run_name>/run_config.json     # window/sequence/split config for that run
└── scalers/<run_name>_scaler.pkl              # feature scaler fit on that run's train split
```

You can disconnect from the network entirely once `python -m pip install -r
requirements.txt` has completed and (if using it) a dataset has been
downloaded.

---

## 6. Wireshark → PCAP Workflow

This is the primary input path.

1. Capture traffic in Wireshark (or `tshark -i <iface> -w capture.pcapng`).
2. Export/save as `.pcap` or `.pcapng`.
3. Run the forecaster directly on the file — Wireshark's GUI is never
   required for processing; parsing goes through scapy (primary) or
   pyshark/tshark (fallback):

```bash
python3 src/main.py --pcap capture.pcap
```

CSV/flow input (e.g. exported from CICFlowMeter or a public dataset) is
also supported:

```bash
python3 src/main.py --csv traffic.csv
```

---

## 7. Dataset Preparation

No dataset is bundled with this repository (keeps the install offline and
avoids redistributing third-party data). Download what you need separately
and point the loader at the directory:

| Dataset | Where to get it | Adapter name |
|---|---|---|
| CIC-IDS2017 | Canadian Institute for Cybersecurity | `cic-ids2017` |
| CIC-IDS2018 | Canadian Institute for Cybersecurity | `cic-ids2018` |
| UNSW-NB15 | UNSW Canberra Cyber | `unsw-nb15` |
| CTU-13 | Stratosphere IPS project | `ctu-13` |
| CICIoT2023 | Canadian Institute for Cybersecurity | `ciciot2023` |
| LANL Auth Dataset | Los Alamos National Laboratory | `lanl-auth` |
| DARPA IDS datasets | various mirrors | use `--pcap` directly |

Place downloaded CSVs in a directory (e.g. `data/raw/cic-ids2018/`) and train:

```bash
python3 src/train.py --dataset cic-ids2018 --data-dir data/raw/cic-ids2018
```

For the standard UNSW-NB15 download, put both
`UNSW_NB15_training-set.csv` and `UNSW_NB15_testing-set.csv` in the same
directory. The adapter understands native UNSW columns (`srcip`, `sport`,
`dstip`, `dsport`, `proto`, `spkts`, `dpkts`, `sbytes`, `dbytes`,
`attack_cat`, and `label`), trains the temporal risk model, and also saves an
attack-family classifier for categories such as `DoS`, `Generic`, `Exploits`,
and `Reconnaissance`:

```bash
python3 src/train.py --dataset unsw-nb15 --data-dir data/raw/unsw-nb15 \
  --run-name unsw_nb15 --epochs 30
streamlit run src/dashboard.py
```

The dashboard is local-only. Its **Capture and analyze** control runs a
bounded `tshark` capture on the selected Kali interface, displays packet/byte
and protocol telemetry as charts, and reports threat probability, risk,
predicted attack family, and forecast timeline. Install capture support with:

```bash
sudo apt install -y tshark
```

**Adding a new dataset:** write one function in `src/dataset_loaders.py`
that returns records matching the flow/packet schema in
`feature_extraction.py`, add it to `DATASET_ADAPTERS`, and extend
`preprocessing.LABEL_TO_STAGE` for any new label strings it introduces.
Nothing else needs to change.

---

## 8. Feature Definitions

**Packet-level** (from PCAP, via `feature_extraction.py`): timestamp,
src/dst IP & port, protocol, TCP flags, TTL, TCP window size, IP
fragmentation flag, payload size, packet length, inter-arrival time (IAT),
retransmission flag.

**Flow-level** (from CSV datasets): src/dst IP & port, protocol, flag
counts, forward/backward packet & byte totals, flow duration, IAT
mean/std/max.

**Aggregated window state** (34 dimensions, `config.FEATURE_VECTOR_ORDER`):
packet/byte counts, packet-length and IAT statistics, per-flag counts and
SYN rate, unique src/dst IP & port counts, **unique destination ports per
source IP** (the primary port-scan signature), connection frequency,
retransmission rate, TTL statistics, fragmentation ratio, protocol ratios
(TCP/UDP/ICMP), payload-size statistics, **destination-port entropy**
(captures sequential-vs-random port-access behaviour), and
bidirectionality ratios.

Not every input source can populate every field — a flow CSV has no
per-packet TTL variance, for instance. Unavailable fields default to 0.0
and are explicitly reported (never silently fabricated) via
`windowing.report_feature_availability()`, which surfaces in both the CLI
dashboard and the JSON output.

---

## 9. LSTM Architecture / World-Model Concept

`src/world_model.py`'s `NetworkWorldModel`:

- **Input**: a sequence of `sequence_length` past state vectors
  `S(t-L+1) ... S(t)`.
- **Encoder**: a configurable-depth LSTM (`num_lstm_layers`, `hidden_size`,
  `dropout`) producing a fixed-size hidden representation of the sequence.
- **Three heads** off that shared representation:
  - `threat_head` — sigmoid probability of attack at each of the next `K`
    forecast steps.
  - `stage_head` — softmax distribution over the 15 MITRE-aligned stage
    classes, predicted at the forecast horizon.
  - `state_head` — regression predicting the single next state `S(t+1)`,
    which is what makes autoregressive rollout possible.

This setup is what lets the model learn `P(S[t+1] | S[t], S[t-1], ...)`
rather than only a static per-window classification — the same
architecture that makes classification-only IDS tools is extended with a
next-state predictor specifically so it can be run forward in time.

---

## 10. K-Step Forecasting

`NetworkWorldModel.autoregressive_rollout()` implements:

```
S(t) --model--> predicted S(t+1)
predicted S(t+1) appended, oldest state dropped --model--> predicted S(t+2)
... repeated K times ...
```

At each rollout step the threat and stage heads are re-evaluated on the
updated (partially-predicted) sequence, producing a full probability
**timeline** (not just a single horizon number) and a step-by-step **attack
progression** string (e.g. `Reconnaissance → Discovery → Lateral Movement`).

Because each step's input includes the model's own prior predictions,
forecast error compounds with distance — `evaluate.py` reports metrics
**per forecast step** specifically so this degradation is visible and
honest, rather than hidden behind one blended number.

---

## 11. MITRE ATT&CK Stage Mapping

`config.ATTACK_STAGES` lists 15 classes (`BENIGN` + 14 MITRE tactics).
`preprocessing.LABEL_TO_STAGE` is an explicit, human-readable,
easily-extended table mapping each dataset's raw label strings (e.g.
`"PortScan"`, `"DDoS"`, `"FTP-Patator"`) to one of these stages. This
mapping is a design decision documented in code, not a hidden or learned
transformation — audit or extend it directly.

**This mapping is probabilistic behavioural inference, not proof.** The
tool never claims a single packet demonstrates a specific ATT&CK
technique; it reports what stage the *learned model* currently associates
with the observed and forecasted traffic pattern, with an accompanying
confidence score.

---

## 12. Explainability

`src/explain.py` provides, for every alert, a `feature → contribution →
direction` breakdown:

- **SHAP** (`shap.KernelExplainer`) is used when the `shap` package is
  installed, for proper Shapley-value attribution.
- Otherwise, a built-in **occlusion/perturbation** method runs
  automatically (zero extra dependency): each feature is set to the
  training-set mean one at a time, and the resulting change in predicted
  threat probability is that feature's attributed contribution.

Suspicious flows/hosts are ranked by a transparent, rule-based heuristic
(port fan-out, SYN/ACK imbalance, retransmission rate) — not a black box —
so the displayed "reason" string is always literally verifiable against
the data.

---

## 13. Training

```bash
python3 src/train.py --dataset cic-ids2018 --data-dir data/raw/cic-ids2018 \
    --window 10 --sequence-length 12 --forecast-steps 5 --epochs 30 \
    --run-name default
```

Leakage safeguards:
- Train/validation/test is **chronological 70% / 15% / 15%**
  (`preprocessing.chronological_split`) — never shuffled. The split is made
  on windows before sequences are built.
- The feature scaler is **fit only on the training split**.
- Sequences are built independently within each split's index range, so
  no sequence spans the train/val or val/test boundary.
- Training stops with a clear error if any partition is too short to contain
  one complete sequence plus forecast horizon; this prevents silently
  producing an unevaluable model.

The temporal LSTM predicts attack probability, ATT&CK stage, and next state.
Training also saves a Random Forest attack-family classifier using the same
training windows. Its held-out report is printed by `evaluate.py` and supports
normalized classes including **DDoS/DoS**, **Brute Force**, `Normal`, and the
native dataset families. `DDoS`, `DoS Hulk`, `UDP flood`, `SSH-Patator`, and
`FTP-Patator` are normalized consistently for classification and stage mapping.

You can also train directly from a PCAP (labels default to BENIGN if the
capture has no ground truth — appropriate for unsupervised exploration,
not for reported accuracy claims):

```bash
python3 src/train.py --pcap captures/capture.pcap --window 10
```

---

## 14. Evaluation

```bash
python3 src/evaluate.py --run-name default
```

Reports, on the held-out chronological test split, **LSTM vs. Logistic
Regression baseline**:

- Precision, Recall, F1, False Positive Rate, ROC-AUC, PR-AUC (immediate
  next-window detection)
- **Forecast performance broken out by horizon step** (`+1_step` through
  `+K_step`), showing how accuracy changes with forecast distance
- Attack-stage prediction accuracy and macro-F1, with the list of stage
  classes actually present in the test set (so you can see exactly what
  was and wasn't evaluated)

All numbers come from `sklearn.metrics` computed on real held-out
predictions — nothing here is a placeholder or invented figure. A full
JSON report is also written to `reports/<run_name>_evaluation.json`.

---

## 15. Example Output

```
============================================================
       AI NETWORK ATTACK FORECASTER
============================================================
Input: capture.pcap
Window: 10 sec | Forecast: 5 steps
Windows observed: 480

CURRENT THREAT : 82%
RISK LEVEL     : CRITICAL
PREDICTED STAGE: LATERAL MOVEMENT
CONFIDENCE     : 89%

FORECAST
+10 sec : 41%
+20 sec : 55%
+30 sec : 68%
+40 sec : 79%
+50 sec : 86%

ATTACK PROGRESSION
Reconnaissance -> Initial Access -> Discovery -> Lateral Movement

TOP FEATURES
1. syn_rate                    +0.310  (increases threat probability)
2. unique_dst_ports_per_src    +0.240  (increases threat probability)
3. connection_frequency        +0.180  (increases threat probability)
4. std_iat                     +0.110  (increases threat probability)
5. retransmission_rate         +0.070  (increases threat probability)

SUSPICIOUS TRAFFIC
Source          Destination     Ports   Protocol  Reason
10.0.0.23       10.0.0.5        41      TCP       contacted 41 distinct destination ports
...

RECOMMENDATION
Immediate investigation recommended — trajectory points toward lateral
movement. Isolate suspicious hosts if confirmed.
============================================================
```

---

## 16. CLI Commands

```bash
python3 src/main.py --pcap capture.pcap
python3 src/main.py --csv traffic.csv
python3 src/train.py --dataset cic-ids2018 --data-dir data/raw/cic-ids2018
python3 src/evaluate.py --run-name default
python3 src/forecast.py --pcap capture.pcap --steps 5 --run-name default  # --run-name is required in practice; it defaults to "default", which won't exist until you train a run with that name
python3 -m pytest tests/ -v
streamlit run src/streamlit_app.py   # optional local UI

# Bundled synthetic demos (see Quickstart, Section 3) -- no dataset download needed
python3 src/main.py --csv data/raw/demo_synthetic/demo_traffic.csv --run-name demo_bundled
python3 src/evaluate.py --run-name demo_bundled
python3 src/main.py --pcap captures/demo_live_capture.pcap --run-name demo_pcap
```

---

## 17. Limitations

- **Dataset-bounded**: the model can only detect/forecast attack families
  present with adequate examples in its training data. It does not detect
  novel attack types it has never seen anything resembling.
- **Unlabeled PCAP training yields no real threat/stage signal**: if you
  train directly on a raw capture with no ground-truth labels, every
  window defaults to BENIGN (there's nothing else to assign, and the tool
  won't fabricate a label) — so the resulting model's threat/stage heads
  will just report BENIGN/low regardless of input. The bundled
  `demo_pcap` run in the Quickstart section demonstrates this exact
  behavior. Train on labeled data (a flow dataset, or PCAP windows you've
  labeled yourself) if you want meaningful threat/stage predictions; you
  can still *apply* that trained model to unlabeled live captures at
  inference time.
- **Small-data instability**: with too few time windows, the LSTM can
  underperform the simpler baseline (this is expected and is exactly what
  `evaluate.py`'s honest per-model comparison is for — check it before
  trusting a given trained run).
- **Flow-CSV inputs lack several packet-level fields** (TTL, TCP window,
  fragmentation, retransmission, per-packet IAT) — those features default
  to 0.0 for such inputs and are flagged as unavailable, which reduces
  detection power relative to full PCAP input.
- **Autoregressive compounding error**: forecast accuracy degrades with
  horizon distance, since later steps condition on the model's own earlier
  predictions rather than ground truth.
- **Stage mapping is probabilistic**, derived from the dataset's own
  labels via an explicit lookup table — it is only as correct as that
  table and the underlying dataset's labeling.
- **CPU-only**: no GPU-specific code paths; fine for typical laptop-scale
  data, but large datasets will train more slowly than with GPU
  acceleration.
- **Very short PCAP captures can crash `train.py`**: if a capture is short
  enough that the chronological test split has fewer windows than
  `sequence_length + forecast_steps - 1`, sequence construction raises
  `IndexError` rather than a clear error. Verified workaround: reduce
  `--window`/`--sequence-length`/`--forecast-steps` for short captures (see
  Section 3a, item 5), or use a longer capture. Only affects training
  directly from small raw PCAPs — CSV datasets and inference are unaffected.

---

## 18. Reproducibility

- `RANDOM_SEED = 42` (in `config.py`) is applied to numpy and torch at the
  start of `train.py`.
- All hyperparameters live in `config.py` / are passable as `train.py`
  CLI flags — no magic numbers hidden elsewhere.
- `run_config.json` (saved per training run under
  `models/checkpoints/<run_name>/`) records the exact window size,
  sequence length, forecast horizon, split indices, and feature
  availability used for that run, so results can be traced back to their
  exact configuration.
- Chronological (non-random) splitting means re-running training on the
  same input file and config reproduces the same train/val/test
  partition.

---

## 19. Security Notes

This is a **defensive** tool only. It does not implement or facilitate
exploitation, credential theft, malware, persistence mechanisms, or
offensive attack execution of any kind. It analyzes traffic you have
authorization to capture and produces predictive alerts to support
defensive decision-making. Always ensure you have authorization before
capturing or analyzing network traffic that isn't your own.
