"""
windowing.py
============
Aggregates a chronological stream of packet-level or flow-level records
(from feature_extraction.py) into fixed-size time windows, each becoming
one network "state" vector S(t) in FEATURE_VECTOR_ORDER order.

This is the boundary between raw traffic and the world model: everything
downstream (world_model.py) only ever sees these numeric state vectors,
never raw packets. Keeping that boundary strict is what makes the model
"learn behaviour" rather than memorize IP/port signatures — no IP or port
number itself is ever used as a model feature, only aggregate statistics
derived from them (counts, entropy, ratios).

Chronological ordering is preserved throughout: windows are emitted in
strictly increasing time order and no future window's data is allowed to
leak into an earlier window's feature computation (see NOTE in
compute_window_features).
"""

from __future__ import annotations
import math
from collections import defaultdict, Counter
from typing import List, Dict, Any, Tuple

import numpy as np

from config import FEATURE_VECTOR_ORDER, WindowConfig, DEFAULT_WINDOW


def _shannon_entropy(counts: List[int]) -> float:
    total = sum(counts)
    if total == 0:
        return 0.0
    ent = 0.0
    for c in counts:
        if c == 0:
            continue
        p = c / total
        ent -= p * math.log2(p)
    return ent


def _bucket_records(records: List[Dict[str, Any]], window_seconds: int,
                     stride_seconds: int) -> Dict[int, List[Dict[str, Any]]]:
    """
    Assign each record to a window bucket keyed by window start index.
    Uses non-overlapping buckets when stride == window_seconds (the
    default and recommended setting — overlapping windows are supported
    but callers should be aware they introduce correlated/leaky samples
    between adjacent windows if used for training).
    """
    if not records:
        return {}

    t0 = min(r["timestamp"] for r in records)
    buckets: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
    for r in records:
        rel_t = r["timestamp"] - t0
        idx = int(rel_t // stride_seconds) if stride_seconds > 0 else 0
        buckets[idx].append(r)
    return buckets


def compute_window_features(window_records: List[Dict[str, Any]],
                             window_seconds: int) -> Dict[str, float]:
    """
    Compute the FEATURE_VECTOR_ORDER feature dict for a single window's
    worth of records. Works for both packet-native records (with
    src_ip/dst_ip/tcp_flags/etc.) and flow-native CSV records (with
    tot_fwd_pkts/syn_flag_cnt/etc.) by branching on the '_is_flow_record'
    marker set in feature_extraction.py.

    NOTE on leakage: this function only ever reads window_records, which
    by construction (see _bucket_records) contains only records whose
    timestamp falls inside [window_start, window_start + window_seconds).
    No lookahead into future windows occurs here.
    """
    feats = {k: 0.0 for k in FEATURE_VECTOR_ORDER}
    if not window_records:
        return feats

    is_flow = window_records[0].get("_is_flow_record", False)

    if is_flow:
        return _compute_flow_window_features(window_records, window_seconds)
    return _compute_packet_window_features(window_records, window_seconds)


def _compute_packet_window_features(recs: List[Dict[str, Any]], window_seconds: int) -> Dict[str, float]:
    feats = {k: 0.0 for k in FEATURE_VECTOR_ORDER}
    n = len(recs)
    feats["packet_count"] = float(n)
    feats["duration"] = float(window_seconds)

    lengths = np.array([r.get("packet_length", 0) for r in recs], dtype=float)
    payloads = np.array([r.get("payload_size", 0) for r in recs], dtype=float)
    iats = np.array([r.get("iat", 0.0) for r in recs], dtype=float)
    ttls = np.array([r.get("ttl", 0) for r in recs], dtype=float)
    windows_ = np.array([r.get("tcp_window", 0) for r in recs], dtype=float)

    feats["byte_count"] = float(lengths.sum())
    feats["mean_packet_length"] = float(lengths.mean()) if n else 0.0
    feats["std_packet_length"] = float(lengths.std()) if n else 0.0
    feats["mean_payload_size"] = float(payloads.mean()) if n else 0.0
    feats["std_payload_size"] = float(payloads.std()) if n else 0.0
    feats["mean_iat"] = float(iats.mean()) if n else 0.0
    feats["std_iat"] = float(iats.std()) if n else 0.0
    feats["max_iat"] = float(iats.max()) if n else 0.0
    feats["mean_ttl"] = float(ttls.mean()) if n else 0.0
    feats["std_ttl"] = float(ttls.std()) if n else 0.0
    feats["mean_tcp_window"] = float(windows_.mean()) if n else 0.0

    syn = fin = rst = ack = psh = urg = 0
    for r in recs:
        flags = str(r.get("tcp_flags", ""))
        if "S" in flags:
            syn += 1
        if "F" in flags:
            fin += 1
        if "R" in flags:
            rst += 1
        if "A" in flags:
            ack += 1
        if "P" in flags:
            psh += 1
        if "U" in flags:
            urg += 1
    feats["syn_count"] = float(syn)
    feats["syn_rate"] = float(syn) / n if n else 0.0
    feats["fin_count"] = float(fin)
    feats["rst_count"] = float(rst)
    feats["ack_count"] = float(ack)
    feats["psh_count"] = float(psh)
    feats["urg_count"] = float(urg)

    src_ips = Counter(r.get("src_ip", "") for r in recs)
    dst_ips = Counter(r.get("dst_ip", "") for r in recs)
    src_ports = Counter(r.get("src_port", 0) for r in recs)
    dst_ports = Counter(r.get("dst_port", 0) for r in recs)

    feats["unique_src_ips"] = float(len(src_ips))
    feats["unique_dst_ips"] = float(len(dst_ips))
    feats["unique_src_ports"] = float(len(src_ports))
    feats["unique_dst_ports"] = float(len(dst_ports))

    # scan signature: average number of unique destination ports touched
    # per unique source IP (high => port-scanning behaviour)
    dst_ports_per_src: Dict[str, set] = defaultdict(set)
    for r in recs:
        dst_ports_per_src[r.get("src_ip", "")].add(r.get("dst_port", 0))
    if dst_ports_per_src:
        feats["unique_dst_ports_per_src"] = float(
            np.mean([len(v) for v in dst_ports_per_src.values()])
        )

    # connections per unique (src,dst) pair -> frequency of repeated contact
    pair_counts = Counter((r.get("src_ip", ""), r.get("dst_ip", "")) for r in recs)
    feats["connection_frequency"] = float(np.mean(list(pair_counts.values()))) if pair_counts else 0.0

    retrans = sum(1 for r in recs if r.get("is_retransmission", 0))
    feats["retransmission_rate"] = float(retrans) / n if n else 0.0

    frag = sum(1 for r in recs if r.get("ip_frag", 0))
    feats["frag_ratio"] = float(frag) / n if n else 0.0

    proto_counts = Counter(r.get("protocol", "OTHER") for r in recs)
    feats["tcp_ratio"] = proto_counts.get("TCP", 0) / n if n else 0.0
    feats["udp_ratio"] = proto_counts.get("UDP", 0) / n if n else 0.0
    feats["icmp_ratio"] = proto_counts.get("ICMP", 0) / n if n else 0.0

    # bidirectionality: fraction of traffic where reverse (dst->src) flow
    # is also observed in-window (proxy for normal request/response vs.
    # one-directional flood/scan traffic)
    fwd_pairs = set((r.get("src_ip", ""), r.get("dst_ip", "")) for r in recs)
    bidir = sum(1 for (a, b) in fwd_pairs if (b, a) in fwd_pairs)
    feats["bidir_packet_ratio"] = bidir / len(fwd_pairs) if fwd_pairs else 0.0
    feats["bidir_byte_ratio"] = feats["bidir_packet_ratio"]  # same proxy at this granularity

    feats["port_entropy"] = _shannon_entropy(list(dst_ports.values()))

    return feats


def _compute_flow_window_features(recs: List[Dict[str, Any]], window_seconds: int) -> Dict[str, float]:
    feats = {k: 0.0 for k in FEATURE_VECTOR_ORDER}
    n = len(recs)
    feats["packet_count"] = float(sum(r.get("tot_fwd_pkts", 0) + r.get("tot_bwd_pkts", 0) for r in recs))
    feats["byte_count"] = float(sum(r.get("totlen_fwd_pkts", 0) + r.get("totlen_bwd_pkts", 0) for r in recs))
    feats["duration"] = float(window_seconds)

    iat_means = np.array([r.get("flow_iat_mean", 0.0) for r in recs], dtype=float)
    iat_stds = np.array([r.get("flow_iat_std", 0.0) for r in recs], dtype=float)
    iat_maxs = np.array([r.get("flow_iat_max", 0.0) for r in recs], dtype=float)
    feats["mean_iat"] = float(iat_means.mean()) if n else 0.0
    feats["std_iat"] = float(iat_stds.mean()) if n else 0.0
    feats["max_iat"] = float(iat_maxs.max()) if n else 0.0

    feats["syn_count"] = float(sum(r.get("syn_flag_cnt", 0) for r in recs))
    feats["syn_rate"] = feats["syn_count"] / n if n else 0.0
    feats["fin_count"] = float(sum(r.get("fin_flag_cnt", 0) for r in recs))
    feats["rst_count"] = float(sum(r.get("rst_flag_cnt", 0) for r in recs))
    feats["ack_count"] = float(sum(r.get("ack_flag_cnt", 0) for r in recs))
    feats["psh_count"] = float(sum(r.get("psh_flag_cnt", 0) for r in recs))
    feats["urg_count"] = float(sum(r.get("urg_flag_cnt", 0) for r in recs))

    src_ips = Counter(r.get("src_ip", "") for r in recs)
    dst_ips = Counter(r.get("dst_ip", "") for r in recs)
    src_ports = Counter(r.get("src_port", 0) for r in recs)
    dst_ports = Counter(r.get("dst_port", 0) for r in recs)
    feats["unique_src_ips"] = float(len(src_ips))
    feats["unique_dst_ips"] = float(len(dst_ips))
    feats["unique_src_ports"] = float(len(src_ports))
    feats["unique_dst_ports"] = float(len(dst_ports))

    dst_ports_per_src: Dict[str, set] = defaultdict(set)
    for r in recs:
        dst_ports_per_src[r.get("src_ip", "")].add(r.get("dst_port", 0))
    if dst_ports_per_src:
        feats["unique_dst_ports_per_src"] = float(
            np.mean([len(v) for v in dst_ports_per_src.values()])
        )

    pair_counts = Counter((r.get("src_ip", ""), r.get("dst_ip", "")) for r in recs)
    feats["connection_frequency"] = float(np.mean(list(pair_counts.values()))) if pair_counts else 0.0

    proto_counts = Counter(str(r.get("protocol", "")).upper() for r in recs)
    # CSV datasets often encode protocol numerically (6=TCP,17=UDP,1=ICMP)
    tcp_n = proto_counts.get("TCP", 0) + proto_counts.get("6", 0)
    udp_n = proto_counts.get("UDP", 0) + proto_counts.get("17", 0)
    icmp_n = proto_counts.get("ICMP", 0) + proto_counts.get("1", 0)
    feats["tcp_ratio"] = tcp_n / n if n else 0.0
    feats["udp_ratio"] = udp_n / n if n else 0.0
    feats["icmp_ratio"] = icmp_n / n if n else 0.0

    fwd_lens = np.array([r.get("totlen_fwd_pkts", 0) for r in recs], dtype=float)
    fwd_pkts = np.array([max(r.get("tot_fwd_pkts", 0), 1) for r in recs], dtype=float)
    per_pkt = fwd_lens / fwd_pkts
    feats["mean_payload_size"] = float(per_pkt.mean()) if n else 0.0
    feats["std_payload_size"] = float(per_pkt.std()) if n else 0.0
    feats["mean_packet_length"] = feats["mean_payload_size"]
    feats["std_packet_length"] = feats["std_payload_size"]

    fwd = np.array([r.get("tot_fwd_pkts", 0) for r in recs], dtype=float)
    bwd = np.array([r.get("tot_bwd_pkts", 0) for r in recs], dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.where(fwd > 0, bwd / fwd, 0.0)
    feats["bidir_packet_ratio"] = float(np.clip(ratio, 0, 1).mean()) if n else 0.0
    feats["bidir_byte_ratio"] = feats["bidir_packet_ratio"]

    feats["port_entropy"] = _shannon_entropy(list(dst_ports.values()))
    # retransmission / TTL / frag / window info generally absent from flow
    # CSVs — left at 0.0 and reported as unavailable (see report_feature_availability)
    return feats


def build_state_sequence(records: List[Dict[str, Any]],
                          window_cfg: WindowConfig = DEFAULT_WINDOW
                          ) -> Tuple[np.ndarray, List[Dict[str, Any]], List[float]]:
    """
    Convert a chronologically-ordered record stream into:
      - state_matrix: np.ndarray of shape (num_windows, FEATURE_DIM),
                       strictly ordered S(t-2) -> S(t-1) -> S(t) -> ...
      - raw_windows:  list of the raw records belonging to each window
                       (kept for explainability / suspicious-flow reporting)
      - window_start_times: list of each window's start timestamp (seconds
                       relative to first packet), for the forecast UI.
    """
    if not records:
        return np.zeros((0, len(FEATURE_VECTOR_ORDER))), [], []

    records = sorted(records, key=lambda r: r["timestamp"])
    buckets = _bucket_records(records, window_cfg.window_seconds, window_cfg.stride_seconds)

    max_idx = max(buckets.keys())
    rows = []
    raw_windows = []
    start_times = []
    for idx in range(max_idx + 1):
        window_recs = buckets.get(idx, [])
        feats = compute_window_features(window_recs, window_cfg.window_seconds)
        rows.append([feats[k] for k in FEATURE_VECTOR_ORDER])
        raw_windows.append(window_recs)
        start_times.append(idx * window_cfg.stride_seconds)

    return np.array(rows, dtype=np.float32), raw_windows, start_times


def report_feature_availability(records: List[Dict[str, Any]]) -> Dict[str, bool]:
    """
    Returns which raw fields were actually present/populated in the input
    (as opposed to defaulted to 0). Surfaced in the UI/README so users
    know which forecast features are backed by real data for their
    specific input source, and which are structurally unavailable.
    """
    if not records:
        return {}
    is_flow = records[0].get("_is_flow_record", False)
    if is_flow:
        return {
            "ttl": False, "tcp_window": False, "ip_frag": False,
            "is_retransmission": False, "per_packet_iat": False,
            "flow_aggregates": True,
        }
    return {
        "ttl": True, "tcp_window": True, "ip_frag": True,
        "is_retransmission": True, "per_packet_iat": True,
        "flow_aggregates": False,
    }
