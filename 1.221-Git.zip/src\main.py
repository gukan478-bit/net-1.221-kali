"""
main.py
=======
The primary CLI entry point: runs the full pipeline on a PCAP or CSV and
renders the plain-text terminal dashboard. Fully offline; no network
access is performed at any point in this script.

Usage:
    python3 main.py --pcap capture.pcap
    python3 main.py --csv traffic.csv
    python3 main.py --pcap capture.pcap --window 10 --steps 5 --run-name default
"""

from __future__ import annotations
import argparse
import logging
import os
import sys
import time
import tracemalloc
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from forecast import run_forecast, ForecasterNotTrainedError
from feature_extraction import PacketParseError

logging.basicConfig(level=logging.WARNING, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")


BANNER_WIDTH = 60


def memory_status() -> str:
    """Return lightweight process memory telemetry without a hard dependency."""
    current, peak = tracemalloc.get_traced_memory()
    rss = 0
    try:
        import resource
        rss = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if sys.platform != "darwin":
            rss *= 1024
    except (ImportError, AttributeError):
        pass
    tracked_mb = peak / (1024 * 1024)
    rss_mb = rss / (1024 * 1024)
    return f"Python tracked peak: {tracked_mb:.1f} MB | process peak: {rss_mb:.1f} MB"


def render_dashboard(result: dict) -> str:
    lines = []
    bar = "=" * BANNER_WIDTH
    lines.append(bar)
    lines.append("       AI NETWORK ATTACK FORECASTER".center(BANNER_WIDTH))
    lines.append(bar)
    lines.append(f"Input: {result['input']}")
    lines.append(f"Window: {result['window_seconds']} sec | Forecast: {result['forecast_steps']} steps")
    lines.append(f"Windows observed: {result['total_windows_observed']}")
    lines.append(f"Memory: {memory_status()}")
    lines.append("")

    prob_pct = result["current_threat_probability"] * 100
    lines.append(f"CURRENT THREAT : {prob_pct:.0f}%")
    lines.append(f"RISK LEVEL     : {result['risk_level']}")
    lines.append(f"PREDICTED STAGE: {result['predicted_stage'].replace('_', ' ')}")
    lines.append(f"CONFIDENCE     : {result['confidence'] * 100:.0f}%")
    lines.append("")

    lines.append("FORECAST")
    for step in result["forecast_timeline"]:
        lines.append(f"+{step['offset_seconds']} sec : {step['probability'] * 100:.0f}%")
    lines.append("")

    lines.append("ATTACK PROGRESSION")
    lines.append(" -> ".join(s.replace("_", " ").title() for s in result["attack_progression"]))
    lines.append("")

    lines.append("TOP FEATURES")
    for i, feat in enumerate(result["top_features"], 1):
        val = feat["contribution"]
        sign = "+" if val >= 0 else "-"
        lines.append(
            f"{i}. {feat['feature']:<28} value={feat.get('current_value', 0):>10.3f} "
            f"impact={sign}{abs(val):.6f}  ({feat['direction']})"
        )
    lines.append("")

    lines.append("SUSPICIOUS TRAFFIC")
    if result["suspicious_flows"]:
        lines.append(f"{'Source':<16}{'Destination':<16}{'Ports':<8}{'Protocol':<10}Reason")
        for f in result["suspicious_flows"]:
            lines.append(f"{f['source']:<16}{f['destination']:<16}{f['port_count']:<8}"
                         f"{f['protocol']:<10}{f['reason']}")
    else:
        lines.append("(none flagged in current window, or input is flow-CSV based "
                      "— per-host ranking unavailable for aggregated flow records)")
    lines.append("")

    lines.append("RECOMMENDATION")
    lines.append(result["recommendation"])
    lines.append(bar)

    unavailable = [k for k, v in result.get("feature_availability", {}).items() if not v]
    if unavailable:
        lines.append(f"Note: features unavailable for this input source: {', '.join(unavailable)}")
        lines.append(bar)

    return "\n".join(lines)


def run_input(input_path: str, run_name: str, steps: int | None = None) -> None:
    """Analyze one user-selected file and render a complete result."""
    started = time.perf_counter()
    try:
        result = run_forecast(input_path, run_name=run_name, steps=steps)
    except ForecasterNotTrainedError as e:
        print(f"\n[ERROR] {e}\n", file=sys.stderr)
        return
    except PacketParseError as e:
        print(f"\n[ERROR] Could not parse input: {e}\n", file=sys.stderr)
        return
    except ValueError as e:
        print(f"\n[ERROR] {e}\n", file=sys.stderr)
        return
    print(render_dashboard(result))
    print(f"Analysis time: {time.perf_counter() - started:.2f} seconds")


def interactive_mode(run_name: str, steps: int | None = None) -> None:
    """Persistent terminal menu; E exits and F analyzes a selected file."""
    tracemalloc.start()
    print("Interactive mode ready. Press F to analyze a CSV/PCAP or E to exit.")
    while True:
        try:
            choice = input("\n[F] Insert file and analyze  [E] Exit\n> ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            return
        if choice in {"e", "exit", "q", "quit"}:
            print("Exiting.")
            return
        if choice not in {"f", "file"}:
            print("Choose F to insert a file or E to exit.")
            continue
        raw_path = input("File path (.csv, .pcap, .pcapng): ").strip().strip('"')
        if not raw_path:
            print("No file path entered.")
            continue
        path = Path(raw_path).expanduser()
        if not path.is_file():
            print(f"File not found: {path}")
            continue
        if path.suffix.lower() not in {".csv", ".tsv", ".pcap", ".pcapng", ".cap"}:
            print("Unsupported file type. Use CSV, TSV, PCAP, PCAPNG, or CAP.")
            continue
        run_input(str(path), run_name, steps)


def main():
    tracemalloc.start()
    parser = argparse.ArgumentParser(
        description="AI Network Attack Forecaster — offline early-warning system for Kali Linux."
    )
    src = parser.add_mutually_exclusive_group()
    src.add_argument("--pcap", help="Path to a .pcap/.pcapng capture file (from Wireshark or tshark).")
    src.add_argument("--csv", help="Path to a flow CSV file (e.g. CIC-IDS2017/2018 format).")
    parser.add_argument("--steps", type=int, default=None, help="Override forecast horizon (K steps).")
    parser.add_argument("--run-name", default="default", help="Trained model artifacts to use.")
    parser.add_argument("--json", action="store_true", help="Print raw JSON instead of the dashboard.")
    parser.add_argument("--interactive", action="store_true",
                        help="Keep the terminal open: F analyzes a file, E exits.")
    args = parser.parse_args()

    if args.interactive or not (args.pcap or args.csv):
        interactive_mode(args.run_name, args.steps)
        return
    input_path = args.pcap or args.csv
    try:
        result = run_forecast(input_path, run_name=args.run_name, steps=args.steps)
    except ForecasterNotTrainedError as e:
        print(f"\n[ERROR] {e}\n", file=sys.stderr)
        sys.exit(1)
    except PacketParseError as e:
        print(f"\n[ERROR] Could not parse input: {e}\n", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"\n[ERROR] {e}\n", file=sys.stderr)
        sys.exit(1)

    if args.json:
        import json
        print(json.dumps(result, indent=2))
    else:
        print(render_dashboard(result))


if __name__ == "__main__":
    main()
